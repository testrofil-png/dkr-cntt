import { 
  Controller, 
  Get, 
  Post, 
  Body, 
  UseGuards, 
  Req, 
  HttpCode, 
  HttpStatus, 
  UseInterceptors
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../../common/guards/auth.guard';
import { RateLimitGuard } from '../../common/guards/rate-limit.guard';
import { BillingService } from './billing.service';
import { CreateCheckoutDto, VerificationPaymentDto } from './dto/billing.dto';
import { LoggingInterceptor } from '../../common/interceptors/logging.interceptor';

@ApiTags('Billing')
@ApiBearerAuth()
@UseGuards(AuthGuard, RateLimitGuard)
@UseInterceptors(LoggingInterceptor)
@Controller('api/billing')
export class BillingController {
  constructor(private readonly billingService: BillingService) {}

  @Get('overview')
  @ApiOperation({ summary: 'Obtenir l\'état général de l\'abonnement et de la consommation' })
  @ApiResponse({ status: 200, description: 'Vue d\'ensemble récupérée.' })
  async getOverview(@Req() req) {
    const userId = req.user.id;
    return this.billingService.getUserBillingOverview(userId);
  }

  @Post('checkout')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Initier un paiement mobile-first (Wave, Orange, Stripe)' })
  @ApiResponse({ status: 201, description: 'Lien de paiement ou instructions générées.' })
  async createCheckout(
    @Req() req,
    @Body() checkoutDto: CreateCheckoutDto
  ) {
    const userId = req.user.id;
    return this.billingService.initiateCheckout(userId, checkoutDto);
  }

  @Post('verify')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Vérifier manuellement ou forcer la validation d\'un paiement en cours' })
  async verifyPayment(
    @Req() req,
    @Body() verifyDto: VerificationPaymentDto
  ) {
    const userId = req.user.id;
    return this.billingService.verifyLocalPayment(userId, verifyDto);
  }

  @Get('invoices')
  @ApiOperation({ summary: 'Récupérer l\'historique des factures de l\'utilisateur' })
  async getInvoices(@Req() req) {
    const userId = req.user.id;
    return this.billingService.getUserInvoices(userId);
  }
}
