import { Injectable, BadRequestException, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCheckoutDto, VerificationPaymentDto } from './dto/billing.dto';
import { SubscriptionStatus, PaymentMethod } from '@prisma/client';

@Injectable()
export class BillingService {
  private readonly logger = new Logger(BillingService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getUserBillingOverview(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        subscription: {
          include: { plan: true }
        },
        invoices: {
          orderBy: { createdAt: 'desc' },
          take: 10
        }
      }
    });

    if (!user) {
      throw new NotFoundException('Utilisateur introuvable');
    }

    const usageCount = await this.prisma.usage.count({
      where: { userId, createdAt: { gte: user.subscription?.startedAt } }
    });

    return {
      user: {
        name: user.name,
        email: user.email,
        companyName: user.companyName
      },
      subscription: user.subscription ? {
        id: user.subscription.id,
        planTitle: user.subscription.plan.title,
        status: user.subscription.status,
        creditsUsed: user.subscription.creditsUsed,
        creditsTotal: user.subscription.creditsTotal,
        billingInterval: user.subscription.billingInterval,
        endsAt: user.subscription.endsAt,
        isActive: user.subscription.status === SubscriptionStatus.ACTIVE
      } : null,
      usagePercent: user.subscription ? (user.subscription.creditsUsed / user.subscription.creditsTotal) * 100 : 0,
      usageCount,
      invoices: user.invoices
    };
  }

  async initiateCheckout(userId: string, dto: CreateCheckoutDto) {
    const { planId, method, billingInterval } = dto;
    
    // 1. Récupération du forfait
    const plan = await this.prisma.plan.findUnique({ where: { id: planId } });
    if (!plan) {
      throw new BadRequestException('Forfait sélectionné invalide');
    }

    // 2. Création d'un paiement en statut "PENDING"
    const reference = `${method.toLowerCase()}_tx_${Math.floor(100000 + Math.random() * 900000)}`;
    
    const payment = await this.prisma.payment.create({
      data: {
        amount: plan.priceFCFA,
        method: method,
        status: 'PENDING',
        reference: reference,
        userId: userId,
      }
    });

    // 3. Intégration API de destination
    if (method === PaymentMethod.WAVE) {
      this.logger.log(`Appel API Wave Sénégal pour générer le lien de paiement. Réf: ${reference}`);
      // Simule le retour de l'API Wave: { launch_url: string, id: string }
      return {
        paymentId: payment.id,
        reference,
        launchUrl: `https://pay.wave.com/checkout/${reference}?amount=${plan.priceFCFA}`,
        method: 'WAVE',
        amount: plan.priceFCFA
      };
    } else if (method === PaymentMethod.ORANGE_MONEY) {
      this.logger.log(`Appel API Orange Money Web Payment. Réf: ${reference}`);
      return {
        paymentId: payment.id,
        reference,
        launchUrl: `https://orange-money.sn/pay-merchant/${reference}`,
        method: 'ORANGE_MONEY',
        amount: plan.priceFCFA
      };
    } else {
      this.logger.log(`Intégration Stripe Card Tokenization pour le montant: ${plan.priceUSD} USD`);
      return {
        paymentId: payment.id,
        reference,
        clientSecret: `pi_stripe_mock_secret_${reference}`,
        method: 'STRIPE',
        amount: plan.priceFCFA
      };
    }
  }

  async verifyLocalPayment(userId: string, dto: VerificationPaymentDto) {
    const { paymentId, reference } = dto;
    
    const payment = await this.prisma.payment.findFirst({
      where: {
        id: paymentId,
        reference,
        userId
      }
    });

    if (!payment) {
      throw new NotFoundException('Transaction ou référence introuvable');
    }

    if (payment.status === 'SUCCESS') {
      return { success: true, status: 'SUCCESS', message: 'Déjà validé' };
    }

    this.logger.log(`Simulation de vérification de statut en temps réel pour ${reference}`);

    // Simulation de validation automatique ultra réactive pour la fintech
    const updatedPayment = await this.prisma.payment.update({
      where: { id: paymentId },
      data: { status: 'SUCCESS' }
    });

    // Activation automatique de l'abonnement
    await this.activateUserSubscription(userId, payment.amount);

    return {
      success: true,
      status: 'SUCCESS',
      message: 'Abonnement et crédits activés automatiquement !'
    };
  }

  private async activateUserSubscription(userId: string, amount: number) {
    let planId = 'plan-starter';
    let credits = 50;
    let title = 'Starter';

    if (amount >= 35000) {
      planId = 'plan-business';
      credits = 999999;
      title = 'Business';
    } else if (amount >= 15000) {
      planId = 'plan-pro';
      credits = 200;
      title = 'Pro';
    }

    const endsAt = new Date();
    endsAt.setMonth(endsAt.getMonth() + 1);

    // Mettre à jour ou créer l'abonnement actif
    await this.prisma.subscription.upsert({
      where: { userId },
      update: {
        planId,
        status: SubscriptionStatus.ACTIVE,
        creditsTotal: credits,
        creditsUsed: 0,
        endsAt
      },
      create: {
        userId,
        planId,
        status: SubscriptionStatus.ACTIVE,
        creditsTotal: credits,
        creditsUsed: 0,
        endsAt
      }
    });

    // Générer la facture correspondante
    const invoiceId = `FAC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const taxAmount = Math.floor(amount * 0.18);
    const subtotal = amount - taxAmount;

    await this.prisma.invoice.create({
      data: {
        id: invoiceId,
        invoiceNumber: invoiceId,
        amount,
        taxAmount,
        subtotal,
        dueDate: endsAt,
        status: 'paid',
        userId,
        paidAt: new Date()
      }
    });

    this.logger.log(`Abonnement ${title} activé pour l'utilisateur ${userId}. Facture ${invoiceId} émise !`);
  }

  async getUserInvoices(userId: string) {
    return this.prisma.invoice.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' }
    });
  }
}
