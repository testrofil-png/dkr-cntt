import { IsString, IsNotEmpty, IsEnum, IsNumber, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export enum BillingPeriod {
  MONTHLY = 'monthly',
  YEARLY = 'yearly'
}

export enum PaymentMethodDto {
  WAVE = 'WAVE',
  ORANGE_MONEY = 'ORANGE_MONEY',
  STRIPE = 'STRIPE'
}

export class CreateCheckoutDto {
  @ApiProperty({ description: 'ID du Plan Sélectionné' })
  @IsString()
  @IsNotEmpty()
  planId: string;

  @ApiProperty({ description: 'Moyen de paiement mobile-first choisi' })
  @IsEnum(PaymentMethodDto)
  @IsNotEmpty()
  method: PaymentMethodDto;

  @ApiProperty({ description: 'Fréquence de facturation', enum: BillingPeriod })
  @IsEnum(BillingPeriod)
  @IsNotEmpty()
  billingInterval: BillingPeriod;

  @IsString()
  @IsOptional()
  couponCode?: string;
}

export class VerificationPaymentDto {
  @ApiProperty({ description: 'ID interne de la transaction générée' })
  @IsString()
  @IsNotEmpty()
  paymentId: string;

  @ApiProperty({ description: 'Référence unique de virement renvoyée' })
  @IsString()
  @IsNotEmpty()
  reference: string;
}
