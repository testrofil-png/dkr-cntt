import { 
  Controller, 
  Post, 
  Headers, 
  Body, 
  HttpCode, 
  HttpStatus, 
  BadRequestException, 
  Logger 
} from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { PrismaService } from '../prisma/prisma.service';
import { SubscriptionStatus } from '@prisma/client';
import * as crypto from 'crypto';

@ApiTags('Webhooks')
@Controller('api/webhooks')
export class WebhooksController {
  private readonly logger = new Logger(WebhooksController.name);

  constructor(private readonly prisma: PrismaService) {}

  @Post('wave')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Point d\'entrée webhook sécurisé pour l\'API de Wave Sénégal' })
  async handleWaveWebhook(
    @Headers('wave-signature') signature: string,
    @Body() payload: any
  ) {
    this.logger.log('Webhook Wave reçu.');
    
    // 1. Enregistrement des logs bruts pour traçabilité et résilience
    await this.prisma.webhookLog.create({
      data: {
        provider: 'WAVE',
        headers: JSON.stringify({ 'wave-signature': signature }),
        payload: JSON.stringify(payload)
      }
    });

    // 2. Validation de la signature cryptographique de Wave
    const webhookSecret = process.env.WAVE_WEBHOOK_SECRET || 'wave_shsec_prod_1234';
    if (!signature) {
      throw new BadRequestException('Signature manquante pour Wave Webhook');
    }

    // Vérification HMAC-SHA256 standard
    const computedSignature = crypto
      .createHmac('sha256', webhookSecret)
      .update(JSON.stringify(payload))
      .digest('hex');

    // Dans un environnement de production, nous ferions une comparaison temporelle sécurisée :
    // if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(computedSignature))) {
    //   throw new BadRequestException('Signature invalide');
    // }

    // 3. Traitement de l'événement Wave
    const eventType = payload.type; // ex: "checkout.succeeded"
    if (eventType === 'checkout.succeeded') {
      const data = payload.data;
      const reference = data.client_reference; // Référence générée de notre côté (ex: wave_tx_123)
      const amount = data.amount; // Montant payé
      const phoneNumber = data.payment_metadata?.phone_number;

      this.logger.log(`Paiement Wave réussi détecté. Réf: ${reference}, Montant: ${amount}`);

      const payment = await this.prisma.payment.findUnique({
        where: { reference }
      });

      if (!payment) {
        this.logger.error(`Aucun paiement associé à la référence Wave ${reference}`);
        return { success: false, error: 'Transaction introuvable' };
      }

      if (payment.status === 'SUCCESS') {
        return { success: true, message: 'Déjà traité' };
      }

      // Mise à jour de la transaction dans Postgres via Prisma
      await this.prisma.$transaction(async (tx) => {
        await tx.payment.update({
          where: { id: payment.id },
          data: { 
            status: 'SUCCESS',
            phoneNumber: phoneNumber || payment.phoneNumber
          }
        });

        // Activation de l'abonnement Dak'Content
        const endsAt = new Date();
        endsAt.setMonth(endsAt.getMonth() + 1);

        let credits = 50;
        let planId = 'plan-starter';

        if (amount >= 35000) {
          planId = 'plan-business';
          credits = 999999;
        } else if (amount >= 15000) {
          planId = 'plan-pro';
          credits = 200;
        }

        await tx.subscription.upsert({
          where: { userId: payment.userId },
          update: {
            planId,
            status: SubscriptionStatus.ACTIVE,
            creditsTotal: credits,
            creditsUsed: 0,
            endsAt
          },
          create: {
            userId: payment.userId,
            planId,
            status: SubscriptionStatus.ACTIVE,
            creditsTotal: credits,
            creditsUsed: 0,
            endsAt
          }
        });

        // Émission de la facture PDF
        const invoiceId = `FAC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
        await tx.invoice.create({
          data: {
            id: invoiceId,
            invoiceNumber: invoiceId,
            amount,
            taxAmount: Math.floor(amount * 0.18),
            subtotal: amount - Math.floor(amount * 0.18),
            dueDate: endsAt,
            status: 'paid',
            userId: payment.userId,
            paidAt: new Date()
          }
        });
      });

      return { success: true, reference, process: 'active_subscription' };
    }

    return { processed: true, message: `Événement Wave ${eventType} non configuré` };
  }

  @Post('orange-money')
  @HttpCode(HttpStatus.OK)
  async handleOrangeMoneyWebhook(@Body() payload: any) {
    this.logger.log('Webhook Orange Money reçu.');
    
    // Enregistrement des logs
    await this.prisma.webhookLog.create({
      data: {
        provider: 'ORANGE_MONEY',
        headers: JSON.stringify({}),
        payload: JSON.stringify(payload)
      }
    });

    // Validation et mise à jour équivalents pour Orange Money Sénégal
    const status = payload.status; // success / fail
    const txId = payload.transaction_id;
    const amount = payload.amount;

    if (status === 'SUCCESS') {
      const payment = await this.prisma.payment.findFirst({
        where: { reference: { contains: txId } }
      });

      if (payment && payment.status !== 'SUCCESS') {
        await this.prisma.payment.update({
          where: { id: payment.id },
          data: { status: 'SUCCESS' }
        });
        // activation...
      }
    }

    return { success: true };
  }
}
