/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Sparkles, 
  ArrowRight, 
  Smartphone, 
  CheckCircle, 
  Play, 
  ChevronDown, 
  HelpCircle, 
  FileText, 
  Layout, 
  TrendingUp, 
  Briefcase, 
  Send,
  Plus, 
  Trash2, 
  Share2, 
  Bell, 
  User, 
  Flame, 
  ExternalLink,
  Loader2,
  Lock,
  MessageSquare,
  DollarSign,
  Monitor,
  Video,
  Database,
  Info,
  Layers,
  Image as ImageIcon,
  Zap,
  PhoneCall,
  X,
  Volume2,
  Search,
  CreditCard,
  Receipt,
  Calendar,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Award,
  ShieldCheck,
  Check,
  Download
} from "lucide-react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip,
  BarChart,
  Bar,
  Legend
} from "recharts";

import Sidebar from "./components/Sidebar";
import UploadZone from "./components/UploadZone";
import PosterCanvas from "./components/PosterCanvas";
import VideoMockup from "./components/VideoMockup";
import BillingSystem from "./components/BillingSystem";
import { Project, PosterLayout, UserProfile, Template, Invoice } from "./types";
import { STAGE_TEMPLATES, PRI_PLANS, INVOICE_DATA, FREQUENT_QUESTIONS } from "./data";

export default function App() {
  // Navigation states
  const [currentPath, setCurrentPath] = useState<string>("/");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // User auth states
  const [user, setUser] = useState<UserProfile>({
    name: "Awa Diop",
    email: "awa.diop@boutique-wax.sn",
    companyName: "Dakar Princesse",
    preferredCategory: "Mode",
    country: "Sénégal",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=300",
    creditsUsed: 14,
    creditsTotal: 50,
    tier: "Starter",
    isLoggedIn: false
  });

  // Auth Forms states
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authCompany, setAuthCompany] = useState("");
  const [authCategory, setAuthCategory] = useState("Mode");
  const [authCountry, setAuthCountry] = useState("Sénégal");
  const [isOnboarding, setIsOnboarding] = useState(false);

  // App project states
  const [projectsList, setProjectsList] = useState<Project[]>([]);
  const [loadingProjects, setLoadingProjects] = useState(false);

  // Workspace active project generation state
  const [inputDescription, setInputDescription] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Mode");
  const [selectedCampaignType, setSelectedCampaignType] = useState("Facebook");
  const [additionalInstructions, setAdditionalInstructions] = useState("");
  
  // Base64 Product Image Holder
  const [productImageBase64, setProductImageBase64] = useState<string | null>(null);

  // Generation Loading states
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState(0);
  const generationSteps = [
    "Analyse de la photo produit par l'IA...",
    "Rédaction de l'accroche et des slogans locaux...",
    "Création du visuel d'affiche Premium...",
    "Génération des scènes vidéo adaptées au format...",
    "Optimisation pour le marché Ouest-Africain..."
  ];

  // Generated active product workspace holder
  const [activeGenerationResult, setActiveGenerationResult] = useState<{
    slogan: string;
    facebookText: string;
    instagramCaption: string;
    hashtags: string[];
    posterLayout: PosterLayout;
    tiktokScript: {
      hook: string;
      scenes: any[];
    };
  } | null>(null);

  // active tab inside creative results view
  const [activeOutputTab, setActiveOutputTab] = useState<"poster" | "video" | "copy">("poster");

  // FAQ open/close states
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Landing Page Interactive Before/After slider position
  const [beforeAfterPosition, setBeforeAfterPosition] = useState(50);

  // Billing interactive payment popup modallers
  const [activePaymentModal, setActivePaymentModal] = useState<{
    planTitle: string;
    price: string;
    currency: string;
    method: "Wave" | "Orange" | "Stripe" | null;
  } | null>(null);

  const [simulatedCheckoutSuccess, setSimulatedCheckoutSuccess] = useState(false);

  // Premium UX states Added
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchPaletteOpen, setSearchPaletteOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [stripeFormActive, setStripeFormActive] = useState(false);

  // Projects Search & Filter inside visual search elements
  const [projectFilterCategory, setProjectFilterCategory] = useState("Tous");
  const [projectFilterCampaign, setProjectFilterCampaign] = useState("Tous");
  const [projectSearchInput, setProjectSearchInput] = useState("");
  const [projectSortOrder, setProjectSortOrder] = useState<"newest" | "name">("newest");

  // Custom notifications state data mockup
  const [notificationList, setNotificationList] = useState([
    { id: 1, text: "Affiche de la collection de Wax prête pour téléchargement HD !", type: "success", time: "Il y a 3 min", unread: true },
    { id: 2, text: "Abonnement Pro activé avec succès via Wave Sénégal (+200 crédits IA)", type: "payment", time: "Il y a 2h", unread: false },
    { id: 3, text: "Nouveau modèle d'affiche 'Bissap Bio' ajouté à la bibliothèque", type: "system", time: "Il y a 1 jour", unread: false }
  ]);

  // Telemetry server monitor logs
  const [serverHealth, setServerHealth] = useState<any>(null);

  // Fetch projects list from central DB API
  const fetchProjects = async () => {
    setLoadingProjects(true);
    try {
      const res = await fetch("/api/projects");
      const list = await res.json();
      setProjectsList(list);
    } catch (e) {
      console.error("Error fetching projects:", e);
    } finally {
      setLoadingProjects(false);
    }
  };

  // Fetch mock server health parameters to display in settings telemetry
  const fetchHealth = async () => {
    try {
      const res = await fetch("/api/health");
      const data = await res.json();
      setServerHealth(data);
    } catch (e) {
      console.warn("Could not retrieve server health.");
    }
  };

  useEffect(() => {
    fetchProjects();
    fetchHealth();
  }, []);

  // Listen for Command Palette shortcut (Ctrl/Cmd + K) and Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        setSearchPaletteOpen((prev) => !prev);
      } else if (e.key === "Escape") {
        setSearchPaletteOpen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Sync route updates to update backend or settings components
  const handleSetPath = (path: string) => {
    setCurrentPath(path);
  };

  // Handle User logins simulation
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUser({
      ...user,
      email: authEmail || "contact@teranga-styles.sn",
      name: authName || "Awa Diop",
      companyName: authCompany || "Teranga Couture Dakar",
      isLoggedIn: true
    });
    setCurrentPath("/dashboard");
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsOnboarding(true);
  };

  const completeOnboarding = () => {
    setUser({
      ...user,
      name: authName || "Khadim Rassoul",
      email: authEmail || "khadim@shop.sn",
      companyName: authCompany || "Khadim Électronique Abidjan",
      preferredCategory: authCategory,
      country: authCountry,
      isLoggedIn: true
    });
    setIsOnboarding(false);
    setCurrentPath("/dashboard");
  };

  // Run absolute AI Content Generation action
  const handleAIContentRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputDescription) {
      alert("Veuillez saisir une courte description de votre article ou produit.");
      return;
    }

    setIsGenerating(true);
    setGenerationStep(0);

    // Dynamic sequence loader interval
    const stepInterval = setInterval(() => {
      setGenerationStep((p) => {
        if (p < generationSteps.length - 1) {
          return p + 1;
        }
        return p;
      });
    }, 1100);

    try {
      const response = await fetch("/api/generate-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          description: inputDescription,
          category: selectedCategory,
          campaignType: selectedCampaignType,
          additionalInstructions: additionalInstructions
        })
      });

      const generatedData = await response.json();
      clearInterval(stepInterval);
      
      if (generatedData.error) {
        alert(generatedData.error);
        setIsGenerating(false);
        return;
      }

      setActiveGenerationResult(generatedData);
      setActiveOutputTab("poster");
      setIsGenerating(false);

      // Consume user credits simulated
      setUser(prev => ({
        ...prev,
        creditsUsed: Math.min(prev.creditsTotal, prev.creditsUsed + 1)
      }));

    } catch (err: any) {
      clearInterval(stepInterval);
      setIsGenerating(false);
      alert("Erreur technique de communication : " + err.message);
    }
  };

  // Save generated campaign into user projects list
  const handleSaveProject = async () => {
    if (!activeGenerationResult) return;

    const payload = {
      title: `${selectedCategory} - Accroche: ${activeGenerationResult.slogan}`,
      description: inputDescription,
      category: selectedCategory,
      slogan: activeGenerationResult.slogan,
      facebookText: activeGenerationResult.facebookText,
      instagramCaption: activeGenerationResult.instagramCaption,
      hashtags: activeGenerationResult.hashtags,
      campaignType: selectedCampaignType,
      imageUrl: productImageBase64 || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600",
      posterLayout: activeGenerationResult.posterLayout,
      tiktokScript: activeGenerationResult.tiktokScript
    };

    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        alert("🎉 Projet sauvegardé avec succès dans vos Projets Récentes !");
        fetchProjects();
        setCurrentPath("/dashboard/projects");
      }
    } catch (e) {
      console.error("Save error:", e);
      alert("Échec de la sauvegarde.");
    }
  };

  // Delete project trigger from list
  const handleDeleteProject = async (id: string) => {
    if (!confirm("Voulez-vous vraiment supprimer définitivement ce projet ?")) {
      return;
    }
    try {
      const res = await fetch(`/api/projects/${id}`, {
        method: "DELETE"
      });
      const data = await res.json();
      if (data.success) {
        fetchProjects();
      }
    } catch (e) {
      console.error("Delete error:", e);
    }
  };

  // Load a project visual directly to workspace editor
  const handleLoadProjectToWorkspace = (p: Project) => {
    setInputDescription(p.description);
    setSelectedCategory(p.category);
    setSelectedCampaignType(p.campaignType);
    setProductImageBase64(p.imageUrl || null);
    
    // Mount result instantly
    setActiveGenerationResult({
      slogan: p.slogan,
      facebookText: p.facebookText,
      instagramCaption: p.instagramCaption,
      hashtags: p.hashtags,
      posterLayout: p.posterLayout,
      tiktokScript: p.tiktokScript
    });

    setCurrentPath("/dashboard/create");
    setActiveOutputTab("poster");
  };

  // Sub-component state modification for Poster editor
  const handleUpdateActivePosterLayout = (updated: PosterLayout) => {
    if (activeGenerationResult) {
      setActiveGenerationResult({
        ...activeGenerationResult,
        posterLayout: updated
      });
    }
  };

  // Simulate billing Wave/Orange/Stripe payment QR generation
  const handleBuyCredits = (plan: typeof PRI_PLANS[0], method: "Wave" | "Orange" | "Stripe") => {
    setActivePaymentModal({
      planTitle: plan.title,
      price: plan.price,
      currency: method === "Stripe" ? "FCFA" : "FCFA",
      method
    });
    setSimulatedCheckoutSuccess(false);
  };

  const handleSimulatePaymentProcess = () => {
    setSimulatedCheckoutSuccess(true);
    setTimeout(() => {
      // close and add credits
      setUser(prev => ({
        ...prev,
        creditsTotal: prev.creditsTotal + (activePaymentModal?.planTitle.includes("Pro") ? 200 : 50),
        tier: activePaymentModal?.planTitle.includes("Pro") ? "Pro" : prev.tier
      }));
      setActivePaymentModal(null);
      setSimulatedCheckoutSuccess(false);
      alert("💳 Trésor payé avec succès ! Vos crédits IA supplémentaires ont été crédités !");
    }, 2500);
  };

  // Interactive slider calculation for before-after
  const handleBeforeAfterMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const progress = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setBeforeAfterPosition(progress);
  };

  // CTR conversion mock chart data
  const conversionData = [
    { name: "Jav", "Vues Facebook / WA": 1200, "Commandes Wave": 140, "WhatsApp clicks": 400 },
    { name: "Fév", "Vues Facebook / WA": 2300, "Commandes Wave": 310, "WhatsApp clicks": 580 },
    { name: "Mar", "Vues Facebook / WA": 3400, "Commandes Wave": 490, "WhatsApp clicks": 900 },
    { name: "Avr", "Vues Facebook / WA": 4800, "Commandes Wave": 830, "WhatsApp clicks": 1250 },
    { name: "Mai (2026)", "Vues Facebook / WA": 6900, "Commandes Wave": 1590, "WhatsApp clicks": 2800 }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col">
      
      {/* MOCK FRAMEWORK BROWSING ADRESS BAR (To view different paths immediately) */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-2 flex items-center justify-between text-xs gap-3 select-none">
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-500" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
        </div>
        
        {/* URL Bar Frame input */}
        <div className="flex-1 max-w-xl mx-auto rounded-full bg-slate-950 border border-slate-800 px-4 py-1 text-slate-400 font-mono text-center flex items-center justify-center gap-2">
          <Lock className="h-3 w-3 text-emerald-400" />
          <span className="text-slate-500">https://dakcontent.sn</span>
          <span className="text-amber-400 font-medium">{currentPath}</span>
        </div>

        {/* Home Site link selector trigger */}
        <div className="flex items-center gap-4 text-slate-400">
          {currentPath !== "/" && (
            <button 
              onClick={() => handleSetPath("/")}
              className="hover:text-amber-400 font-medium transition-all"
            >
              ← Site Public
            </button>
          )}
          {user.isLoggedIn ? (
            <span className="text-emerald-400 flex items-center gap-1 font-semibold">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              Connecté
            </span>
          ) : (
            <button 
              onClick={() => handleSetPath("/login")}
              className="text-amber-400 font-medium hover:underline"
            >
              Espace Client →
            </button>
          )}
        </div>
      </div>

      {/* RENDER BODY BASED ON PATHWAYS STATEMENT SWITCHES */}

      {/* ==================== 1. PUBLIC LANDING PAGE ROUTE ==================== */}
      {currentPath === "/" && (
        <div className="flex-1 flex flex-col">
          {/* Landing Header */}
          <header className="sticky top-0 z-30 border-b border-slate-900 bg-slate-950/80 backdrop-blur-md px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow">
                <Sparkles className="h-4.5 w-4.5 text-white animate-pulse" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-amber-400 via-rose-300 to-white bg-clip-text text-transparent">
                  Dak’Content
                </span>
                <span className="block text-[8px] tracking-widest text-amber-500 font-mono">WEST AFRICA IA</span>
              </div>
            </div>

            <nav className="hidden md:flex items-center gap-6 text-sm text-slate-300 font-medium">
              <a href="#features" className="hover:text-amber-400 transition-colors">Fonctionnalités</a>
              <a href="#demo" className="hover:text-amber-400 transition-colors">Démo Interactive</a>
              <a href="#pricing" className="hover:text-amber-400 transition-colors">Tarifs Wave</a>
              <a href="#faq" className="hover:text-amber-400 transition-colors">FAQ</a>
            </nav>

            <div className="flex items-center gap-3">
              {user.isLoggedIn ? (
                <button
                  onClick={() => handleSetPath("/dashboard")}
                  className="rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 px-4 py-2 text-xs font-bold text-slate-950 hover:brightness-110 shadow transition-all"
                >
                  Accéder à mon Espace
                </button>
              ) : (
                <>
                  <button
                    onClick={() => handleSetPath("/login")}
                    className="text-xs font-bold text-slate-300 hover:text-white px-3 py-2"
                  >
                    Connexion
                  </button>
                  <button
                    onClick={() => handleSetPath("/register")}
                    className="rounded-xl bg-white text-slate-950 hover:bg-slate-100 px-4 py-2 text-xs font-extrabold uppercase tracking-widest shadow transition-all"
                  >
                    Essai Gratuit
                  </button>
                </>
              )}
            </div>
          </header>

          {/* Hero section */}
          <section className="relative px-6 py-16 sm:py-24 text-center overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 h-72 w-72 sm:h-96 sm:w-96 rounded-full bg-amber-500/10 blur-[120px] pointer-events-none" />
            <div className="absolute bottom-0 right-10 h-72 w-72 rounded-full bg-rose-500/5 blur-[120px] pointer-events-none" />

            <div className="max-w-4xl mx-auto space-y-6">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 px-3.5 py-1 text-xs font-bold text-amber-400">
                <Flame className="h-3 w-3 animate-ping" />
                SaaS IA Révolutionnaire pour PME et Commerçants en Afrique
              </span>

              <h1 className="text-4xl sm:text-6xl font-display font-extrabold tracking-tight text-white leading-[1.1]">
                Créez vos affiches et posts publicitaires en <span className="bg-gradient-to-r from-amber-400 via-rose-400 to-indigo-400 bg-clip-text text-transparent">30 secondes</span>
              </h1>

              <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto">
                Transformez une simple photo produit ou une note vocale WhatsApp en affiches professionnelles HD, posts Facebook/Instagram captivants et vidéos TikTok shorts prêtes à publier.
              </p>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => handleSetPath("/register")}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:brightness-110 px-8 py-4 text-sm font-extrabold text-white shadow-lg shadow-amber-500/10 transition-all hover:scale-[1.02]"
                >
                  Générer mon premier visuel
                  <ArrowRight className="h-4.5 w-4.5" />
                </button>
                <button
                  onClick={() => handleSetPath("/login")}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 px-6 py-4 text-sm font-semibold text-slate-200 transition-all"
                >
                  <MessageSquare className="h-4.5 w-4.5 text-emerald-400" />
                  Se connecter à mon compte
                </button>
              </div>

              {/* Local wallets reassurance icons */}
              <div className="pt-8 flex items-center justify-center gap-6 text-xs text-slate-500">
                <span>Intégré avec :</span>
                <span className="font-bold flex items-center gap-1 text-sky-400">
                  <span className="inline-block h-2 w-2 rounded-full bg-sky-400" />
                  Wave Sénégal
                </span>
                <span className="font-bold flex items-center gap-1 text-orange-500">
                  <span className="inline-block h-2 w-2 rounded-full bg-orange-500" />
                  Orange Money
                </span>
              </div>
            </div>

            {/* Simulated app interface mockup */}
            <div className="relative mt-16 max-w-5xl mx-auto rounded-2xl border border-slate-800 bg-slate-900/40 p-3 shadow-2xl overflow-hidden shadow-amber-500/5">
              <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-950/20 to-transparent pointer-events-none" />
              <img 
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1200" 
                alt="Dak Content UI" 
                referrerPolicy="no-referrer"
                className="rounded-xl border border-slate-800 w-full object-cover max-h-[420px] opacity-75 grayscale shrink-0"
              />
              {/* Overlay badges visual details */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center gap-2 bg-slate-950/80 border border-slate-800 rounded-2xl px-6 py-5 shadow-2xl max-w-sm text-center">
                <Sparkles className="h-8 w-8 text-amber-400 animate-spin" />
                <h3 className="text-base font-bold text-white">Créateur Marketing Intelligent</h3>
                <p className="text-xs text-slate-400">
                  Des milliers de commerçants de Dakar, Abidjan et Bamako l'utilisent déjà pour multiplier par 5 leurs ventes Facebook !
                </p>
              </div>
            </div>
          </section>

          {/* Features bullet layout list */}
          <section id="features" className="px-6 py-20 bg-slate-900/30 border-y border-slate-900">
            <div className="max-w-7xl mx-auto space-y-12">
              <div className="text-center space-y-3">
                <h2 className="text-3xl font-display font-extrabold text-white">Tout ce dont vous avez besoin pour vendre en Afrique</h2>
                <p className="text-slate-400 text-sm max-w-2xl mx-auto">
                  Rédigez des descriptions qui parlent à vos clients locaux et concevez des visuels de classe mondiale.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* Visual Affiches */}
                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-6 space-y-3 hover:border-amber-500/30 transition-all">
                  <div className="h-10 w-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
                    <Layout className="h-5 w-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-100">Génération d'Affiches</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Ajout automatique du titre accrocheur, des tarifs, de votre numéro WhatsApp et de votre QR Wave directement sur l'image de votre article.
                  </p>
                </div>

                {/* Video Tiktok */}
                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-6 space-y-3 hover:border-rose-500/30 transition-all">
                  <div className="h-10 w-10 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
                    <Video className="h-5 w-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-100">Vidéos IA Courtes</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Créez des vidéos de 10 secondes pour TikTok ou Reels, avec transitions de scènes et voix off robotique naturelle intégrée qui parle à vos clients.
                  </p>
                </div>

                {/* WhatsApp Audio */}
                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-6 space-y-3 hover:border-emerald-500/30 transition-all">
                  <div className="h-10 w-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Volume2 className="h-5 w-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-100">Transcription Audios</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Uploadez vos notes vocales enregistrées à la va-vite. Notre IA les transforme instantanément en posts de vente complets et optimisés.
                  </p>
                </div>

                {/* Slogan & Copywriting */}
                <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-6 space-y-3 hover:border-indigo-500/30 transition-all">
                  <div className="h-10 w-10 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <FileText className="h-5 w-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-100">Copywriting Localisé</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Des argumentaires de vente percutants intégrant hashtags tendances, prix en CFA, et facilités de livraison par scooter local.
                  </p>
                </div>

              </div>
            </div>
          </section>

          {/* BEFORE / AFTER INTERACTIVE SLIDER DEMO SECTION */}
          <section id="demo" className="px-6 py-20 max-w-5xl mx-auto space-y-12">
            <div className="text-center space-y-3">
              <h2 className="text-3xl font-display font-extrabold text-white">Résultat visuel impressionnant (Effet WOW)</h2>
              <p className="text-slate-400 text-sm max-w-2xl mx-auto">
                Glissez le curseur de gauche à droite pour voir comment Dak'Content transforme une simple photo amateur brute en affiche marketing de niveau professionnel.
              </p>
            </div>

            {/* Interactive Slider Frame */}
            <div 
              onMouseMove={handleBeforeAfterMove}
              onTouchMove={(e) => {
                if (e.touches[0]) {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = e.touches[0].clientX - rect.left;
                  setBeforeAfterPosition(Math.max(0, Math.min(100, (x / rect.width) * 100)));
                }
              }}
              className="relative aspect-video w-full rounded-2xl overflow-hidden border border-slate-800 select-none cursor-ew-resize group shadow-2xl"
            >
              {/* After: Professional Dak'Content Poster */}
              <div className="absolute inset-0 h-full w-full bg-indigo-950 flex flex-col items-center justify-center text-center p-6">
                
                {/* Beautiful Mockup background inside "After" */}
                <div className="absolute inset-0 bg-cover bg-center brightness-50 contrast-125" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800')` }} />
                
                <div className="absolute top-6 left-6 z-10 bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full tracking-wider">
                  🎉 -20% Tabaski d'Exception
                </div>

                <div className="relative z-10 flex flex-col items-center max-w-md bg-black/60 border border-white/10 p-4 sm:p-6 rounded-2xl backdrop-blur">
                  <h3 className="text-xl sm:text-3xl font-display font-black text-white uppercase tracking-tight">Kaftan Royal Wax</h3>
                  <p className="text-xs sm:text-sm text-amber-300 font-bold tracking-wide mt-2">Confection Artisanale à Dakar Plateau</p>
                  <p className="text-[11px] sm:text-xs text-slate-300 mt-2">
                    Broderies d'or finitions haute couture. 🏍️ Livraison incluse à Dakar.
                  </p>
                  <button className="mt-4 bg-amber-500 text-slate-950 font-bold text-xs uppercase px-4 py-2 rounded-lg tracking-wider">
                    Commander via Wave • 25 000 FCFA
                  </button>
                </div>

                {/* Right water label */}
                <div className="absolute right-6 top-6 bg-emerald-500 text-white font-bold text-xs px-3 py-1 rounded-lg">
                  Dak’Content (APRÈS CONCEPTION) ✨
                </div>
              </div>

              {/* Before: Raw Simple amateur photo client uploads */}
              <div 
                className="absolute inset-y-0 left-0 overflow-hidden bg-slate-900 border-r-2 border-white/60 z-10"
                style={{ width: `${beforeAfterPosition}%` }}
              >
                {/* The identical size background of raw product */}
                <div className="absolute inset-0 h-[540px] w-[960px] max-w-none bg-slate-950 flex flex-col items-center justify-center p-6">
                  <div className="absolute inset-0 bg-cover bg-center opacity-40 grayscale" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800')` }} />
                  {/* Just raw product image text */}
                  <div className="relative z-10 bg-slate-950/80 p-5 rounded-xl border border-slate-800 text-center text-xs max-w-xs text-slate-400">
                    <ImageIcon className="h-8 w-8 text-slate-600 mx-auto mb-2" />
                    <p className="font-bold text-slate-300">Photo produit brute amateur</p>
                    <p className="mt-1 text-[11px] text-slate-500">Sans texte, sombre, sans boutons, non attractive pour Facebook.</p>
                  </div>
                </div>

                {/* Left water label */}
                <div className="absolute left-6 top-6 bg-slate-700/80 text-slate-200 font-bold text-xs px-3 py-1 rounded-lg">
                  PHOTO BRUTE (AVANT)
                </div>
              </div>

              {/* Floating circular sliding bar control handle selector badge */}
              <div 
                className="absolute inset-y-0 h-full w-0 pointer-events-none"
                style={{ left: `${beforeAfterPosition}%` }}
              >
                <div className="absolute -translate-x-1/2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full bg-white shadow-lg flex items-center justify-center border border-slate-300 text-slate-700 font-bold pointer-events-auto cursor-ew-resize">
                  ↔
                </div>
              </div>

            </div>
          </section>

          {/* Pricing subscription plans */}
          <section id="pricing" className="px-6 py-20 bg-slate-900/10 border-t border-slate-900">
            <div className="max-w-7xl mx-auto space-y-12">
              <div className="text-center space-y-3">
                <span className="text-xs font-bold uppercase tracking-widest text-[#FFF] font-mono bg-amber-500/10 px-3 py-1 rounded-full text-amber-500">
                  Tarifs simples transparents
                </span>
                <h2 className="text-3xl font-display font-extrabold text-white">Choisissez le plan adapté à votre croissance</h2>
                <p className="text-slate-400 text-sm max-w-2xl mx-auto">
                  Pas de frais cachés. Nous acceptons Wave Sénégal & Orange Money Côte d'Ivoire.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {PRI_PLANS.map((plan) => (
                  <div 
                    key={plan.id}
                    className={`relative rounded-2xl border bg-slate-950 p-6 flex flex-col justify-between transition-all ${
                      plan.popular 
                        ? "border-amber-500 shadow-xl shadow-amber-500/5 scale-[1.03]" 
                        : "border-slate-800/80"
                    }`}
                  >
                    {plan.popular && (
                      <span className="absolute top-0 right-6 -translate-y-1/2 bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 text-[10px] font-extrabold uppercase px-3 py-1 rounded-full tracking-wider">
                        Recommandé pour les Vendeurs
                      </span>
                    )}

                    <div className="space-y-4">
                      <h3 className="text-lg font-bold text-slate-100">{plan.title}</h3>
                      
                      <div className="pb-4 border-b border-slate-900 flex items-baseline gap-1.5">
                        <span className="text-3xl font-black text-amber-400">{plan.price}</span>
                        <span className="text-sm font-medium text-slate-400">{plan.currency}</span>
                        <span className="text-xs text-slate-500 ml-1">({plan.equivalentUsd})</span>
                      </div>

                      <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5 font-mono py-1 rounded bg-slate-900/60 px-2 w-fit">
                        <Zap className="h-3.5 w-3.5 text-amber-400 animate-bounce" />
                        {plan.credits}
                      </div>

                      {/* features loop */}
                      <ul className="space-y-3 pt-2 text-xs text-slate-300">
                        {plan.features.map((feat, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-8 space-y-2">
                      <button
                        onClick={() => handleBuyCredits(plan, "Wave")}
                        className="w-full rounded-xl bg-amber-500 hover:bg-amber-400 py-2.5 text-xs font-extrabold text-slate-950 uppercase tracking-widest transition-all active:scale-[0.98]"
                      >
                        S'abonner via Wave
                      </button>
                      
                      <button
                        onClick={() => handleBuyCredits(plan, "Orange")}
                        className="w-full rounded-xl bg-orange-600/15 border border-orange-500/30 hover:bg-orange-600/25 py-2.5 text-xs font-extrabold text-orange-400 uppercase tracking-widest transition-all active:scale-[0.98]"
                      >
                        S'abonner via Orange
                      </button>

                      <button
                        onClick={() => handleBuyCredits(plan, "Stripe")}
                        className="w-full rounded-xl bg-emerald-600/15 border border-emerald-500/30 hover:bg-emerald-600/25 py-2.5 text-xs font-extrabold text-emerald-400 uppercase tracking-widest transition-all active:scale-[0.98]"
                      >
                        S'abonner via Stripe / Carte
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* FAQ according panels */}
          <section id="faq" className="px-6 py-20 max-w-3xl mx-auto space-y-12">
            <div className="text-center space-y-3">
              <h2 className="text-3xl font-display font-extrabold text-white">Questions fréquentes</h2>
              <p className="text-slate-450 text-xs">
                Besoin d'aide ? Voici tout ce que vous devez savoir sur Dak'Content.
              </p>
            </div>

            <div className="space-y-3">
              {FREQUENT_QUESTIONS.map((faq, index) => {
                const isOpen = openFaqIndex === index;
                return (
                  <div 
                    key={index}
                    className="rounded-xl border border-slate-850 bg-slate-900/20 overflow-hidden"
                  >
                    <button
                      onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                      className="w-full flex items-center justify-between text-left p-4 focus:outline-none"
                    >
                      <span className="text-sm font-bold text-slate-200">{faq.question}</span>
                      <ChevronDown className={`h-4 w-4 text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                    </button>
                    {isOpen && (
                      <div className="p-4 pt-0 border-t border-slate-900/50 text-xs text-slate-400 leading-relaxed">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* Public Footer */}
          <footer className="border-t border-slate-900 bg-slate-950 px-6 py-10 relative">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
              
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-gradient-to-tr from-amber-500 through-rose-500 to-indigo-600 flex items-center justify-center">
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <div>
                  <span className="text-base font-bold bg-gradient-to-r from-amber-400 to-white bg-clip-text text-transparent">Dak’Content</span>
                  <span className="block text-[8px] tracking-wide text-slate-500 uppercase font-mono">Dakar Cocody Bamako Loft 2026</span>
                </div>
              </div>

              <div className="flex items-center gap-6 text-xs text-slate-500">
                <span>© 2026 Dak'Content SA. Tous droits réservés.</span>
                <a href="#demo" className="hover:underline">Mentions légales</a>
                <a href="#features" className="hover:underline">Conditions d'utilisation</a>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    alert("📞 Service Clientèle active du lundi au samedi par WhatsApp au +221 77 123 45 67 ! Nous serions ravis de vous accompagner !");
                  }}
                  className="rounded-lg bg-emerald-600/10 border border-emerald-500/20 hover:bg-emerald-600/20 px-3 py-1.5 text-xs font-semibold text-emerald-400 flex items-center gap-1.5"
                >
                  <PhoneCall className="h-3.5 w-3.5 animate-bounce" /> WhatsApp Aide : +221 77...
                </button>
              </div>

            </div>
          </footer>
        </div>
      )}

      {/* ==================== 2. AUTH LOGIN & REGISTER VIEW SCREEN ==================== */}
      {(currentPath === "/login" || currentPath === "/register") && (
        <div className="flex-1 flex items-center justify-center px-4 py-16 relative">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 h-72 w-72 rounded-full bg-amber-500/5 blur-[100px] pointer-events-none" />
          
          <div className="w-full max-w-md bg-slate-950 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-6 relative z-10">
            
            {/* Logo */}
            <div className="text-center space-y-1">
              <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center mx-auto mb-2 shadow">
                <Sparkles className="h-5 w-5 text-white animate-pulse" />
              </div>
              <h2 className="text-2xl font-display font-extrabold text-white">
                {currentPath === "/login" ? "Content de vous revoir" : "Créez votre compte gratuit"}
              </h2>
              <p className="text-xs text-slate-400">
                {currentPath === "/login" ? "Accédez à de super arguments et affiches publicitaires" : "Générez vos posts de vente en 30 secondes chrono !"}
              </p>
            </div>

            {/* Standard Login & Register Switch buttons */}
            <div className="grid grid-cols-2 bg-slate-900/60 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => handleSetPath("/login")}
                className={`py-1.5 rounded-md font-bold transition-all ${
                  currentPath === "/login" ? "bg-amber-500 text-slate-950" : "text-slate-400"
                }`}
              >
                Se connecter
              </button>
              <button
                onClick={() => handleSetPath("/register")}
                className={`py-1.5 rounded-md font-bold transition-all ${
                  currentPath === "/register" ? "bg-amber-500 text-slate-950" : "text-slate-400"
                }`}
              >
                Créer un compte
              </button>
            </div>

            {/* Simulated Multi-Step Onboarding Questionnaire */}
            {isOnboarding ? (
              <div className="space-y-4">
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 text-xs text-amber-400 space-y-1">
                  <h4 className="font-bold">Escale d'Onboarding Dak'Content 🌍</h4>
                  <p>Aidez l'IA de Dak'Content à adapter les expressions, le ton des textes et le style des affiches à votre domaine de vente.</p>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Quel est votre secteur de vente ?</label>
                    <select
                      value={authCategory}
                      onChange={(e) => setAuthCategory(e.target.value)}
                      className="w-full rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    >
                      <option value="Mode">Mode (Wax, Kaftans, tresses, cosmétique)</option>
                      <option value="Restauration">Restauration (Cuisine locale dakar, fast food)</option>
                      <option value="Beauté">Beauté & Soins (Spa, coiffeurs)</option>
                      <option value="Électronique">Électronique (Smartphones, Ordinateurs)</option>
                      <option value="Immobilier">Immobilier (Locations d'appartements meublés)</option>
                      <option value="Automobile">Automobile (Berlines d'occasion, location SUV)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Votre zone géographique cible ?</label>
                    <select
                      value={authCountry}
                      onChange={(e) => setAuthCountry(e.target.value)}
                      className="w-full rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    >
                      <option value="Sénégal">Sénégal (Dakar Plateau, Almadies, Thiès)</option>
                      <option value="Côte d'Ivoire">Côte d'Ivoire (Abidjan Cocody, Plateau, Yopougon)</option>
                      <option value="Mali">Mali (Bamako Commune IV, V)</option>
                      <option value="Autre">Autre pays de la Zone CFA / Export</option>
                    </select>
                  </div>

                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={completeOnboarding}
                      className="w-full rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 py-2.5 text-xs font-bold text-slate-950 hover:brightness-110 transition-all flex items-center justify-center gap-1"
                    >
                      <span>Finaliser mon inscription • Lancer</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              // Standard inputs forms for credentials
              <form onSubmit={currentPath === "/login" ? handleLoginSubmit : handleRegisterSubmit} className="space-y-4">
                <div className="space-y-3.5 text-xs text-left">
                  
                  {currentPath === "/register" && (
                    <>
                      <div>
                        <label className="block text-slate-400 font-semibold mb-1">Votre Prénom & Nom</label>
                        <input
                          type="text"
                          required
                          value={authName}
                          onChange={(e) => setAuthName(e.target.value)}
                          placeholder="Awa Diop"
                          className="w-full rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 font-semibold mb-1">Nom de votre Boutique / Entreprise</label>
                        <input
                          type="text"
                          required
                          value={authCompany}
                          onChange={(e) => setAuthCompany(e.target.value)}
                          placeholder="Teranga Couture Dakar"
                          className="w-full rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-medium"
                        />
                      </div>
                    </>
                  )}

                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Adresse électronique (E-mail)</label>
                    <input
                      type="email"
                      required
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="awa.diop@boutique-wax.sn"
                      className="w-full rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-medium"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-slate-400 font-semibold">Votre mot de passe secret</label>
                      {currentPath === "/login" && (
                        <span className="text-[10px] text-slate-500 hover:underline cursor-pointer">Oublié ?</span>
                      )}
                    </div>
                    <input
                      type="password"
                      required
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full rounded-lg bg-slate-900 border border-slate-800 px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                </div>

                <div className="pt-2 text-xs">
                  <button
                    type="submit"
                    className="w-full rounded-xl bg-amber-500 hover:bg-amber-400 py-2.5 text-xs font-bold text-slate-950 uppercase tracking-widest transition-all shadow shadow-amber-500/10"
                  >
                    {currentPath === "/login" ? "Accéder à mon espace" : "Continuer"}
                  </button>

                  <button 
                    type="button"
                    onClick={() => {
                      // bypass simulating demo instantly
                      setUser({
                        ...user,
                        isLoggedIn: true
                      });
                      setCurrentPath("/dashboard");
                    }}
                    className="w-full mt-3 text-center text-[10px] text-slate-500 hover:text-white underline cursor-pointer"
                  >
                    Bypass et explorer le Dashboard directement en démo 🚪
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

      {/* ==================== 3. INTERNAL ACCOUNT DASHBOARD (ALL WORKSPACES PAGE SHELLS) ==================== */}
      {currentPath.startsWith("/dashboard") && (
        <div className="flex-1 flex flex-col lg:flex-row relative">
          
          {/* Sidebar drawer navigation */}
          <Sidebar 
            currentPath={currentPath}
            setPath={handleSetPath}
            user={user}
            isOpen={sidebarOpen}
            setIsOpen={setSidebarOpen}
            isCollapsed={isSidebarCollapsed}
            setIsCollapsed={setIsSidebarCollapsed}
            isDarkMode={isDarkMode}
            onLogout={() => {
              setUser({ ...user, isLoggedIn: false });
              setCurrentPath("/");
            }}
          />

          {/* MAIN DYNAMIC ACCOUNT BODY VIEW FRAME (Right side panel) */}
          <main className={`flex-1 flex flex-col px-4 py-6 sm:p-6 overflow-y-auto min-h-screen transition-colors duration-300 relative ${isDarkMode ? "bg-zinc-950 text-zinc-100" : "bg-slate-50 text-slate-800"}`}>
            
            {/* Topbar inside dashboard */}
            <header className={`flex items-center justify-between pb-4 border-b mb-6 shrink-0 gap-4 transition-colors duration-300 ${isDarkMode ? "border-zinc-900" : "border-slate-200 opacity-90"}`}>
              <div className="flex items-center gap-3">
                {/* Mobile hamburger menu */}
                <button
                  onClick={() => setSidebarOpen(true)}
                  className={`rounded-lg border p-2 lg:hidden transition-colors ${
                    isDarkMode 
                      ? "border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white" 
                      : "border-slate-200 bg-white text-slate-600 hover:text-slate-900 shadow-sm"
                  }`}
                  aria-label="Ouvrir le menu"
                >
                  🍔
                </button>
                <div>
                  <h1 className={`text-xl font-display font-extrabold tracking-tight flex items-center gap-2 ${isDarkMode ? "text-white" : "text-slate-900"}`}>
                    <span>
                      {currentPath === "/dashboard" && "Tableau de Bord"}
                      {currentPath === "/dashboard/create" && "Atelier IA Créative"}
                      {currentPath === "/dashboard/projects" && "Mes Projets Sauvegardés"}
                      {currentPath === "/dashboard/templates" && "Bibliothèque de Modèles"}
                      {currentPath === "/dashboard/analytics" && "Statistiques de Conversion"}
                      {currentPath === "/dashboard/billing" && "Facturation & Tarifs"}
                      {currentPath === "/dashboard/settings" && "Paramètres Profil & API"}
                    </span>
                  </h1>
                  <p className={`text-[11px] font-medium ${isDarkMode ? "text-zinc-400" : "text-slate-500"}`}>
                    Suivi de boutique • <span className="text-orange-600 font-bold uppercase">{user.companyName} ({user.preferredCategory})</span>
                  </p>
                </div>
              </div>

              {/* Action buttons list in topbar */}
              <div className="flex items-center gap-2.5 sm:gap-3">
                {/* Search Bar Trigger - Beautiful sleek modern input pill */}
                <div 
                  onClick={() => setSearchPaletteOpen(true)}
                  className={`hidden md:flex items-center gap-2.5 rounded-full border px-3.5 py-1.5 text-xs font-medium cursor-pointer transition-all ${
                    isDarkMode 
                      ? "bg-zinc-900/60 border-zinc-800/80 text-zinc-450 hover:bg-zinc-805 text-zinc-400 hover:border-zinc-700" 
                      : "bg-slate-100 border-slate-200 text-slate-500 hover:bg-slate-200/50 hover:border-slate-300"
                  }`}
                  title="Ouvrir la recherche globale (Cmd + K)"
                >
                  <span>🔍</span>
                  <span>Rechercher...</span>
                  <kbd className={`rounded px-1.5 py-0.5 text-[9px] font-mono shadow-sm ${isDarkMode ? "bg-zinc-800 border border-zinc-700 text-zinc-500" : "bg-white border text-slate-400"}`}>
                    ⌘K
                  </kbd>
                </div>

                {/* Light/Dark Toggle */}
                <button
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  className={`rounded-lg p-2 border transition-colors text-sm ${
                    isDarkMode 
                      ? "border-zinc-800 bg-zinc-900 text-amber-400 hover:text-amber-300" 
                      : "border-slate-200 bg-white text-slate-600 hover:text-amber-600 shadow-sm"
                  }`}
                  title={isDarkMode ? "Passer en mode clair" : "Passer en mode sombre"}
                >
                  {isDarkMode ? "☀️ clair" : "🌙 sombre"}
                </button>

                <button 
                  onClick={() => handleSetPath("/dashboard/billing")}
                  className={`hidden sm:flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold transition-all border ${
                    isDarkMode 
                      ? "bg-amber-500/10 border-amber-500/20 text-amber-400 hover:bg-amber-500/15" 
                      : "bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100 shadow-sm"
                  }`}
                >
                  <Zap className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
                  <span>Crédits : {user.creditsTotal - user.creditsUsed}</span>
                </button>

                {/* Notification Dropdown Container */}
                <div className="relative">
                  <header 
                    onClick={() => setShowNotifications(!showNotifications)}
                    className={`relative cursor-pointer p-2 rounded-lg border transition-all ${
                      isDarkMode 
                        ? "border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white" 
                        : "border-slate-200 bg-white text-slate-600 hover:text-slate-900 shadow shadow-sm"
                    }`}
                  >
                    <Bell className="h-4.5 w-4.5" />
                    {notificationList.some(n => n.unread) && (
                      <span className="absolute top-[4px] right-[4px] h-1.5 w-1.5 rounded-full bg-rose-500 ring-1 ring-white animate-ping" />
                    )}
                  </header>

                  {/* Dropdown panel */}
                  {showNotifications && (
                    <>
                      <div className="fixed inset-0 z-10" onClick={() => setShowNotifications(false)} />
                      <div className={`absolute right-0 mt-2 w-80 rounded-xl border p-4 shadow-xl z-20 transition-all duration-200 ${
                        isDarkMode 
                          ? "bg-zinc-950 border-zinc-900 text-zinc-100" 
                          : "bg-white border-slate-200 text-slate-800"
                      }`}>
                        <div className="flex justify-between items-center mb-3">
                          <h4 className="text-sm font-bold">Notifications</h4>
                          <button 
                            onClick={() => {
                              setNotificationList(prev => prev.map(n => ({ ...n, unread: false })));
                            }}
                            className="text-[10px] text-orange-600 font-bold hover:underline"
                          >
                            Tout marquer comme lu
                          </button>
                        </div>
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {notificationList.map(notif => (
                            <div 
                              key={notif.id} 
                              className={`p-2.5 rounded-lg border text-xs transition-colors ${
                                notif.unread 
                                  ? (isDarkMode ? "bg-zinc-900/60 border-orange-550/20" : "bg-orange-50/50 border-orange-200") 
                                  : (isDarkMode ? "bg-zinc-900/20 border-transparent text-zinc-400" : "bg-slate-50 border-transparent text-slate-500")
                              }`}
                            >
                              <p className="font-medium">{notif.text}</p>
                              <span className="text-[9px] text-zinc-400 mt-1 block">{notif.time}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </header>

            {/* SUB-ROUTE 3.1: DASHBOARD LANDING PAGE PREVIEWS */}
            {currentPath === "/dashboard" && (
              <div className="space-y-6">
                
                {/* Statistics Cards Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  
                  {/* Total Designs */}
                  <div className="rounded-xl border border-slate-900 bg-slate-900/40 p-5 space-y-2 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-24 w-24 rounded-full bg-amber-500/5 blur-xl pointer-events-none" />
                    <span className="text-xs text-slate-450 font-medium block">Total Campagnes créées</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold font-mono text-slate-50">{projectsList.length}</span>
                      <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 px-1 py-0.5 rounded flex items-center gap-0.5">
                        <TrendingUp className="h-2.5 w-2.5" /> +24% ce mois
                      </span>
                    </div>
                  </div>

                  {/* Available Credits */}
                  <div className="rounded-xl border border-slate-900 bg-slate-900/40 p-5 space-y-2 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-24 w-24 rounded-full bg-rose-500/5 blur-xl pointer-events-none" />
                    <span className="text-xs text-slate-450 font-medium block">Crédits AI Restants</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold font-mono text-amber-400">{user.creditsTotal - user.creditsUsed}</span>
                      <span className="text-[10px] text-slate-400">sur {user.creditsTotal}</span>
                    </div>
                  </div>

                  {/* Click conversions (CTR) */}
                  <div className="rounded-xl border border-slate-900 bg-slate-900/40 p-5 space-y-2 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-24 w-24 rounded-full bg-emerald-500/5 blur-xl pointer-events-none" />
                    <span className="text-xs text-slate-450 font-medium block">Clics WhatsApp générés</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold font-mono text-slate-50">2,840</span>
                      <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 px-1 py-0.5 rounded">
                        Conversion: 12.4%
                      </span>
                    </div>
                  </div>

                  {/* Category Target */}
                  <div className="rounded-xl border border-slate-900 bg-slate-900/40 p-5 space-y-2 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-24 w-24 rounded-full bg-indigo-500/5 blur-xl pointer-events-none" />
                    <span className="text-xs text-slate-450 font-medium block">Secteur Cible Principal</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-lg font-extrabold text-[#FFF] tracking-tight">{user.preferredCategory}</span>
                      <span className="text-[10px] text-slate-400 font-mono">/ {user.country}</span>
                    </div>
                  </div>

                </div>

                {/* Main analytical graph and quick actions generator section */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  
                  {/* Left Column (8 Cols): Recharts conversion graph */}
                  <div className="lg:col-span-8 rounded-2xl border border-slate-900 bg-slate-900/20 p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-bold text-slate-100">Evolution des conversions & Commandes Wave reçues</h4>
                        <p className="text-[11px] text-slate-400">Statistiques agrégées sur vos liens de paiement Wave & messages WhatsApp finalisés.</p>
                      </div>
                      <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-2 py-1 rounded">
                        Live CTR tracker
                      </span>
                    </div>

                    <div className="h-64 h-full w-full min-h-[240px]">
                      <ResponsiveContainer width="100%" height={240}>
                        <AreaChart data={conversionData}>
                          <defs>
                            <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#D97706" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#D97706" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorClicks" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10B981" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                          <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} />
                          <YAxis stroke="#94A3B8" fontSize={11} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: "#0F172A", border: "1px solid #334155" }} 
                            labelStyle={{ color: "#F8FAFC", fontWeight: "bold" }}
                          />
                          <Area type="monotone" dataKey="Vues Facebook / WA" stroke="#3B82F6" strokeWidth={1} fillOpacity={0} />
                          <Area type="monotone" dataKey="WhatsApp clicks" stroke="#D97706" strokeWidth={2.5} fill="url(#colorViews)" />
                          <Area type="monotone" dataKey="Commandes Wave" stroke="#10B981" strokeWidth={2.5} fill="url(#colorClicks)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Right Column (4 Cols): AI Credit token count remaining gauge */}
                  <div className="lg:col-span-4 rounded-2xl border border-slate-900 bg-slate-900/20 p-5 flex flex-col justify-between">
                    <div className="space-y-3">
                      <h4 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                        <Zap className="h-4.5 w-4.5 text-amber-500 animate-pulse" />
                        Usage Intelligent
                      </h4>
                      <p className="text-[11px] text-slate-400">Vos crédits se consument par requêtes de création d'affiches ou de vidéos.</p>
                      
                      <div className="pt-4 flex flex-col items-center justify-center relative">
                        {/* Circular progress simulated */}
                        <div className="h-28 w-28 rounded-full border-8 border-slate-800 flex flex-col items-center justify-center relative">
                          <span className="text-2xl font-black font-mono text-amber-400">
                            {Math.round(((user.creditsTotal - user.creditsUsed) / user.creditsTotal) * 100)}%
                          </span>
                          <span className="text-[9px] text-slate-400 uppercase font-bold tracking-tight mt-0.5">restants</span>
                          <div className="absolute inset-2 rounded-full border border-dashed border-amber-500/20 pointer-events-none" />
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleSetPath("/dashboard/create")}
                      className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 p-3 text-xs font-bold text-slate-950 uppercase tracking-widest transition-all"
                    >
                      <span>Lancer l'Atelier IA ✨</span>
                    </button>
                  </div>

                </div>

                {/* Recent saved projects list */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                    <h4 className="text-sm font-bold text-slate-100">Campagnes de Vente Récentes</h4>
                    <button 
                      onClick={() => handleSetPath("/dashboard/projects")}
                      className="text-xs text-amber-400 hover:underline"
                    >
                      Voir tous mes projets ({projectsList.length}) →
                    </button>
                  </div>

                  {loadingProjects ? (
                    <div className="flex h-24 items-center justify-center text-slate-500">
                      <Loader2 className="h-6 w-6 animate-spin text-amber-400 mr-2" />
                      <span>Chargement de vos projets...</span>
                    </div>
                  ) : projectsList.length === 0 ? (
                    <div className="rounded-xl border border-slate-900 p-8 text-center text-xs text-slate-500">
                      Aucun projet enregistré. Lancez l'Atelier IA ci-dessus pour générer du contenu publicitaire !
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {projectsList.slice(0, 3).map((proj) => (
                        <div 
                          key={proj.id}
                          className="group relative rounded-xl border border-slate-900 bg-slate-950 p-4 hover:border-amber-500/30 transition-all flex flex-col justify-between space-y-3"
                        >
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="inline-block px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-400 rounded">
                                {proj.category}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                {new Date(proj.createdAt).toLocaleDateString("fr-FR")}
                              </span>
                            </div>
                            <h5 className="text-sm font-bold text-slate-100 truncate">{proj.title}</h5>
                            <p className="text-xs text-slate-400 line-clamp-2 italic">"{proj.slogan}"</p>
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-slate-900">
                            <button
                              onClick={() => handleLoadProjectToWorkspace(proj)}
                              className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                            >
                              <span>Charger Éditeur</span>
                              <ArrowRight className="h-3 w-3" />
                            </button>
                            <button
                              onClick={() => handleDeleteProject(proj.id)}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-rose-400 hover:bg-rose-950/20"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Clean minimalist advice tip */}
                <div className="rounded-xl border border-zinc-800 bg-zinc-900/10 p-4 flex items-start gap-3">
                  <Sparkles className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-zinc-100">Astuce Dak'Content</h5>
                    <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed">
                      Optimisez vos publications en ajoutant des stickers de prix ou des numéros de téléphone directement sur les visuels pour stimuler les commandes d'achat immédiat sur WhatsApp.
                    </p>
                  </div>
                </div>

              </div>
            )}

            {/* SUB-ROUTE 3.2: THE ULTIMATE WORKSPACE GENERATOR MODULE */}
            {currentPath === "/dashboard/create" && (
              <div className="space-y-6">
                
                {/* Visual workflow step input panels */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                  
                  {/* Left parameter inputs cards form (5 Cols) */}
                  <form onSubmit={handleAIContentRequest} className="xl:col-span-5 space-y-5">
                    
                    <div className="rounded-2xl border border-slate-900 bg-slate-900/30 p-5 space-y-4">
                      
                      <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                        <span className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                          <Layers className="h-4 w-4 text-amber-500 animate-pulse" />
                          Configuration de base
                        </span>
                        <span className="text-[10px] bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full font-bold uppercase">
                          Étape 1 & 2
                        </span>
                      </div>

                      {/* Select Industry category */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-450 mb-1.5">Secteur d'activité de votre boutique</label>
                        <select 
                          value={selectedCategory}
                          onChange={(e) => setSelectedCategory(e.target.value)}
                          className="w-full rounded-xl bg-slate-950 border border-slate-850 px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                        >
                          <option value="Mode">Mode d'Afrique (Wax, Kaftans, robes de fêtes)</option>
                          <option value="Restauration">Restauration Locale (Thiébou, Yassa, Mafé, Grillades)</option>
                          <option value="Beauté">Beauté & Cosmétique (Salon de tresses nappy, beurre de karité)</option>
                          <option value="Électronique">Électronique (Vente smartphones Dakar Plateau)</option>
                          <option value="Immobilier">Immobilier (Locations d'appartements de prestige)</option>
                          <option value="Automobile">Location Automobile & SUV</option>
                          <option value="Autre">Autre commerce de proximité / Services</option>
                        </select>
                      </div>

                      {/* Core Content brief uploads images zones */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-450 mb-2">Charger la photo de votre produit</label>
                        <UploadZone 
                          selectedImage={productImageBase64}
                          onImageSelected={(base64) => setProductImageBase64(base64)}
                          onAudioTranscribed={(text) => setInputDescription(text)}
                        />
                      </div>

                      {/* Long Prompt brief inputs */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-450 mb-1.5 flex justify-between">
                          <span>Description abrégée de votre article</span>
                          <span className="text-[10px] text-slate-500">Parlez face caméra ou tapez</span>
                        </label>
                        <textarea
                          rows={4}
                          required
                          value={inputDescription}
                          onChange={(e) => setInputDescription(e.target.value)}
                          placeholder="Décrivez votre produit (ex: Superbe Robe Wax de qualité supérieure brodée à la main, livrable à Dakar Plateau via scooter, paiement par Wave)."
                          className="w-full rounded-xl bg-slate-950 border border-slate-850 px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500 leading-relaxed font-semibold placeholder:font-normal"
                        />
                      </div>

                      {/* Choose Main Platform */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-450 mb-1.5">Réseau social visé en priorité</label>
                        <div className="grid grid-cols-3 gap-2 text-xs">
                          {["Facebook", "Instagram", "TikTok"].map((c) => (
                            <button
                              type="button"
                              key={c}
                              onClick={() => setSelectedCampaignType(c)}
                              className={`py-2 rounded-lg border text-center font-bold tracking-wide transition-all ${
                                selectedCampaignType === c 
                                  ? "bg-amber-400 text-slate-950 border-amber-400" 
                                  : "bg-slate-950 border-slate-850 text-slate-400 hover:text-white"
                              }`}
                            >
                              {c}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Advanced options instructions */}
                      <div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-450 mb-1.5 cursor-pointer hover:text-slate-350">
                          <Info className="h-3 w-3 text-amber-500" />
                          <span>Instructions avancées ou ton recherché (optionnel)</span>
                        </div>
                        <input
                          type="text"
                          value={additionalInstructions}
                          onChange={(e) => setAdditionalInstructions(e.target.value)}
                          placeholder="Ex: Utiliser un ton vendeur très dynamique, mentionner Wave Sénégal."
                          className="w-full rounded-lg bg-slate-950 border border-slate-850 px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      {/* Generation trigger */}
                      {isGenerating ? (
                        <div className="rounded-xl bg-slate-900/60 p-4 border border-slate-800 space-y-3">
                          <div className="flex items-center gap-3">
                            <Loader2 className="h-5 w-5 animate-spin text-amber-500 shrink-0" />
                            <span className="text-xs font-bold text-slate-200">{generationSteps[generationStep]}</span>
                          </div>
                          <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-500 animate-pulse"
                              style={{ width: `${((generationStep + 1) / generationSteps.length) * 100}%` }}
                            />
                          </div>
                        </div>
                      ) : (
                        <button
                          type="submit"
                          className="w-full rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-650 hover:brightness-115 p-3.5 text-xs font-black text-slate-950 uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/5 active:scale-95"
                        >
                          <Sparkles className="h-4.5 w-4.5 text-slate-950 animate-bounce" />
                          <span>Générer ma campagne complète IA ✨</span>
                        </button>
                      )}

                    </div>

                    {/* Prepopulated templates direct shortcuts */}
                    <div className="rounded-xl border border-slate-900 bg-slate-900/10 p-4 space-y-3">
                      <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase flex items-center gap-1">
                        <Zap className="h-3 w-3 text-amber-500" /> Démarrer avec un modèle express :
                      </span>
                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        {STAGE_TEMPLATES.slice(0, 4).map((tpl) => (
                          <div 
                            key={tpl.id}
                            onClick={() => {
                              setSelectedCategory(tpl.category);
                              setInputDescription(tpl.description);
                              setProductImageBase64(tpl.imageUrl);
                            }}
                            className="p-2 rounded bg-slate-950 border border-slate-900 hover:border-amber-500/40 text-left cursor-pointer transition-all hover:bg-slate-900/40 divide-y-0 text-slate-300 truncate font-semibold"
                          >
                            🏷️ {tpl.title}
                          </div>
                        ))}
                      </div>
                    </div>

                  </form>

                  {/* Right generated asset workstation details (7 Cols) */}
                  <div className="xl:col-span-7 space-y-5">
                    
                    {activeGenerationResult ? (
                      <div className="space-y-4">
                        
                        {/* Upper Tab switch bar triggers */}
                        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-900 gap-1.5 text-xs font-semibold shadow justify-between sm:justify-start">
                          <button
                            onClick={() => setActiveOutputTab("poster")}
                            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
                              activeOutputTab === "poster" ? "bg-amber-400 text-slate-950 shadow" : "text-slate-400 hover:text-white"
                            }`}
                          >
                            <Layout className="h-4 w-4" /> Affiche Graphique
                          </button>
                          <button
                            onClick={() => setActiveOutputTab("video")}
                            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
                              activeOutputTab === "video" ? "bg-amber-400 text-slate-950 shadow" : "text-slate-400 hover:text-white"
                            }`}
                          >
                            <Video className="h-4 w-4" /> Vidéo IA TikTok
                          </button>
                          <button
                            onClick={() => setActiveOutputTab("copy")}
                            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
                              activeOutputTab === "copy" ? "bg-amber-400 text-slate-950 shadow" : "text-slate-400 hover:text-white"
                            }`}
                          >
                            <FileText className="h-4 w-4" /> Textes Publicitaires
                          </button>
                        </div>

                        {/* Rendering core Tab asset content */}

                        {/* Tab 1: Poster visual adjustable graphics canvas */}
                        {activeOutputTab === "poster" && (
                          <PosterCanvas 
                            layout={activeGenerationResult.posterLayout}
                            imageUrl={productImageBase64 || undefined}
                            onUpdateLayout={handleUpdateActivePosterLayout}
                          />
                        )}

                        {/* Tab 2: Tik Tok dynamic voice video preview mockup */}
                        {activeOutputTab === "video" && (
                          <VideoMockup 
                            script={activeGenerationResult.tiktokScript}
                            productImage={productImageBase64 || undefined}
                            categoryName={selectedCategory}
                          />
                        )}

                        {/* Tab 3: Copywriter conversion texts tailored West Africa */}
                        {activeOutputTab === "copy" && (
                          <div className="space-y-5 rounded-2xl border border-slate-800 bg-slate-950 p-5">
                            
                            {/* Facebook copywriting panel */}
                            <div className="space-y-2 text-xs">
                              <span className="inline-block font-mono text-[10px] font-bold text-sky-400 uppercase tracking-wider">
                                📘 Post Facebook à copier et coller :
                              </span>
                              <div className="relative">
                                <textarea
                                  rows={8}
                                  readOnly
                                  value={activeGenerationResult.facebookText}
                                  className="w-full rounded-xl bg-slate-900 border border-slate-810 p-3 text-slate-200 leading-relaxed font-semibold focus:outline-none"
                                />
                                <button
                                  onClick={() => {
                                    navigator.clipboard.writeText(activeGenerationResult.facebookText);
                                    alert("📘 Post Facebook copié dans votre presse-papiers !");
                                  }}
                                  className="absolute bottom-3 right-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-[10px] font-bold px-2 py-1 rounded"
                                >
                                  Copier le post
                                </button>
                              </div>
                            </div>

                            {/* Instagram Hook caption panel */}
                            <div className="space-y-2 text-xs pt-3 border-t border-slate-900">
                              <span className="inline-block font-mono text-[10px] font-bold text-rose-400 uppercase tracking-wider">
                                📸 Caption Instagram & Tags :
                              </span>
                              <div className="relative">
                                <textarea
                                  rows={5}
                                  readOnly
                                  value={activeGenerationResult.instagramCaption}
                                  className="w-full rounded-xl bg-slate-900 border border-slate-810 p-3 text-slate-200 leading-relaxed font-semibold focus:outline-none"
                                />
                                <button
                                  onClick={() => {
                                    navigator.clipboard.writeText(activeGenerationResult.instagramCaption);
                                    alert("📸 Caption Instagram copiée !");
                                  }}
                                  className="text-[10px] font-bold absolute bottom-3 right-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2 py-1 rounded"
                                >
                                  Copier
                                </button>
                              </div>
                            </div>

                            {/* Hashtags list */}
                            <div className="flex flex-wrap gap-2 pt-2 text-xs">
                              {activeGenerationResult.hashtags.map((tag, i) => (
                                <span key={i} className="px-2.5 py-1 rounded-full bg-slate-900 text-slate-350 border border-slate-800 text-[11px] font-mono">
                                  #{tag}
                                </span>
                              ))}
                            </div>

                          </div>
                        )}

                        {/* Bottom action panel buttons for saves and export downloads */}
                        <div className="rounded-xl border border-slate-900 bg-slate-900/30 p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                          <div className="flex items-center gap-2">
                            <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                            <span className="text-xs text-slate-300">Génération par modèle Gemini 3.5-flash terminée.</span>
                          </div>

                          <div className="flex items-center gap-2.5 w-full sm:w-auto">
                            <button
                              onClick={handleSaveProject}
                              className="w-full sm:w-auto flex items-center justify-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-xs font-bold text-white shadow"
                            >
                              <CheckCircle className="h-4 w-4" /> Enregistrer ce Projet
                            </button>
                            <button
                              onClick={() => {
                                alert("📤 Campagne complète prête à l'envoi ! Fichiers de téléchargement générés (PNG & MP4).");
                              }}
                              className="w-full sm:w-auto flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 px-4 py-2 text-xs font-semibold text-slate-300 border border-slate-700"
                            >
                              <Share2 className="h-4 w-4" /> Partager
                            </button>
                          </div>
                        </div>

                      </div>
                    ) : (
                      // Empty generation state screen
                      <div className="rounded-3xl border border-dashed border-slate-850 bg-slate-900/5 p-12 text-center text-slate-400 flex flex-col items-center justify-center min-h-[460px] space-y-4">
                        <div className="h-16 w-16 rounded-full bg-slate-900 flex items-center justify-center mb-2">
                          <Sparkles className="h-8 w-8 text-slate-600 animate-pulse" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-slate-300">En attente de votre configuration...</h3>
                          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                            Saisissez les spécifications de vos kaftans, plats de Thiéboudienne ou smartphones à gauche puis cliquez sur Générer pour voir opérer l'IA.
                          </p>
                        </div>
                      </div>
                    )}

                  </div>

                </div>

              </div>
            )}

            {/* SUB-ROUTE 3.3: PROJECTS HISTORY */}
            {currentPath === "/dashboard/projects" && (
              <div className="space-y-5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                  <h3 className="text-base font-bold text-slate-200">Campagnes de Vente Archivées</h3>
                  <span className="text-xs text-slate-450 font-mono font-bold">({projectsList.length} projets au total)</span>
                </div>

                {loadingProjects ? (
                  <div className="flex min-h-[220px] items-center justify-center text-slate-500">
                    <Loader2 className="h-8 w-8 animate-spin text-amber-500 mr-2" />
                    <span>Chargement de votre historique...</span>
                  </div>
                ) : projectsList.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-slate-850 p-12 text-center text-slate-500 space-y-3">
                    <Database className="h-10 w-10 text-slate-700 mx-auto" />
                    <p className="text-sm">Aucune campagne n'a encore été enregistrée.</p>
                    <button
                      onClick={() => handleSetPath("/dashboard/create")}
                      className="rounded-lg bg-amber-500 text-slate-950 font-bold px-4 py-2 text-xs"
                    >
                      Prendre un premier Essai IA
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {projectsList.map((proj) => (
                      <div 
                        key={proj.id}
                        className="rounded-2xl border border-slate-900 bg-slate-950 p-5 flex flex-col justify-between space-y-4 shadow hover:border-slate-800 transition-all"
                      >
                        <div className="space-y-2.5">
                          <div className="flex items-center justify-between text-xs">
                            <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-bold uppercase text-[9px]">
                              {proj.category}
                            </span>
                            <span className="text-slate-500 font-mono text-[10px]">
                              {new Date(proj.createdAt).toLocaleDateString("fr-FR", { month: "short", day: "numeric", year: "numeric" })}
                            </span>
                          </div>
                          
                          <h4 className="text-sm font-bold text-slate-100 line-clamp-1">{proj.title}</h4>
                          <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">"{proj.description}"</p>
                          
                          {/* Slogan details */}
                          <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-900">
                            <span className="block text-[9px] font-bold text-amber-500 font-mono uppercase mb-0.5">Slogan IA :</span>
                            <p className="text-xs text-slate-200 italic">"{proj.slogan}"</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-3 border-t border-slate-900">
                          <button
                            onClick={() => handleLoadProjectToWorkspace(proj)}
                            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                          >
                            <span>Charger en Atelier</span>
                            <ArrowRight className="h-3 w-3" />
                          </button>

                          <button
                            onClick={() => handleDeleteProject(proj.id)}
                            className="p-1.5 rounded hover:bg-rose-950/20 text-slate-650 hover:text-rose-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SUB-ROUTE 3.4: TEMPLATE MARKETPLACE GALLERY */}
            {currentPath === "/dashboard/templates" && (
              <div className="space-y-6">
                
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-2 border-b border-slate-900">
                  <div>
                    <h3 className="text-base font-bold text-slate-200">Galerie de Modèles Prédéfinis</h3>
                    <p className="text-[11px] text-slate-400">Sélectionnez un modèle validé aux Almadies, Cocody et Plateau pour accélérer votre promotion.</p>
                  </div>
                  <span className="text-xs text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded font-bold uppercase">
                    Afrique Francophone 2026 Editions
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {STAGE_TEMPLATES.map((tpl) => (
                    <div 
                      key={tpl.id}
                      className="rounded-2xl border border-slate-900 bg-slate-950 overflow-hidden flex flex-col justify-between hover:border-slate-800 transition-all shadow group"
                    >
                      {/* Image slot with badge */}
                      <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                        <img 
                          src={tpl.imageUrl} 
                          alt={tpl.title} 
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <span className="absolute top-3 left-3 bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded shadow">
                          {tpl.badge}
                        </span>
                        <span className="absolute top-3 right-3 bg-slate-950/80 text-white text-[10px] font-bold px-2.5 py-0.5 rounded backdrop-blur">
                          {tpl.category}
                        </span>
                      </div>

                      <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                        <div className="space-y-1.5">
                          <h4 className="text-sm font-bold text-slate-100">{tpl.title}</h4>
                          <p className="text-xs text-slate-400 leading-relaxed">{tpl.description}</p>
                        </div>

                        <div className="pt-4 border-t border-slate-900 flex items-center justify-between">
                          <button
                            onClick={() => {
                              setSelectedCategory(tpl.category);
                              setInputDescription(tpl.description || "");
                              setProductImageBase64(tpl.imageUrl);
                              // pop preset results simulation
                              setActiveGenerationResult({
                                slogan: `L'éclat unique pour ${tpl.category}! ✨`,
                                facebookText: `✨ ANNONCE EXCLUSIVE ${tpl.title.toUpperCase()} ✨\n\nCommandes en cours d'enregistrement pour notre collection limitée.\n\n🛵 Livré à domicile en 24h.\n👉 Écrivez-nous par WhatsApp !`,
                                instagramCaption: `${tpl.title} est enfin disponible ! Qu'en pensez-vous ? ✨`,
                                hashtags: [tpl.category, "DakContentStyle", "TerangaPrestige"],
                                posterLayout: {
                                  title: tpl.title,
                                  subtitle: tpl.description.slice(0, 30) + "...",
                                  accentColor: tpl.accentColor,
                                  bgColor: tpl.bgColor,
                                  badgeText: tpl.badge,
                                  ctaText: "Acheter"
                                },
                                tiktokScript: {
                                  hook: `Découvrez la splendeur de ${tpl.title} ! 👇`,
                                  scenes: [
                                    { sceneNumber: 1, description: "Fils d'or sur la soie.", textOverlay: "Luxe absolu", voiceOver: "Entrez dans l'univers de l'excellence africaine." }
                                  ]
                                }
                              });
                              setCurrentPath("/dashboard/create");
                              setActiveOutputTab("poster");
                            }}
                            className="bg-amber-400 text-slate-950 font-bold text-xs uppercase px-4 py-2 rounded-lg tracking-wide hover:bg-amber-300 w-full text-center"
                          >
                            Utiliser ce modèle
                          </button>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>

              </div>
            )}

            {/* SUB-ROUTE 3.5: PERFORMANCE ANALYTICS */}
            {currentPath === "/dashboard/analytics" && (
              <div className="space-y-6">
                
                <div className="rounded-2xl bg-amber-500/10 border border-amber-500/20 p-5 flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-amber-400">Votre taux de conversion moyen s'élève à 12.4% 📈</h4>
                    <p className="text-xs text-slate-350">Vos campagnes Dak'Content performent particulièrement bien ce trimestre grâce aux expressions en langue locale wolof intégrées.</p>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-50 border border-amber-500/30 px-3 py-1 bg-slate-950/40 rounded-full">
                    Dakar Market Share +1.4%
                  </span>
                </div>

                {/* Additional detailed metrics graphs with BarCharts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  
                  {/* Graph 1 */}
                  <div className="rounded-xl border border-slate-900 bg-slate-900/35 p-5 space-y-3">
                    <h5 className="text-sm font-bold text-slate-100">Répartition des clics prospects par canaux</h5>
                    <div className="h-64 h-full w-full">
                      <ResponsiveContainer width="100%" height={240}>
                        <BarChart data={conversionData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                          <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} />
                          <YAxis stroke="#94A3B8" fontSize={11} />
                          <Tooltip contentStyle={{ backgroundColor: "#0F172A" }} />
                          <Legend wrapperStyle={{ fontSize: 11 }} />
                          <Bar dataKey="WhatsApp clicks" fill="#D97706" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="Commandes Wave" fill="#10B981" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Marketing Campaign advice card */}
                  <div className="rounded-xl border border-zinc-805 border-zinc-800 bg-zinc-900/10 p-5 space-y-3 flex flex-col justify-between">
                    <div>
                      <h5 className="text-sm font-bold text-zinc-100 mb-2">Guide d'Impact des Campagnes</h5>
                      <p className="text-xs text-zinc-400 leading-relaxed mb-3">Maximisez la portée de vos contenus publicitaires auprès du public d'Afrique francophone en appliquant nos recommandations structurelles.</p>
                      
                      <div className="rounded bg-zinc-950 p-3 border border-zinc-900 text-xs text-zinc-400 space-y-2.5">
                        <div className="flex items-start gap-2">
                          <span className="text-orange-500 font-bold">1.</span>
                          <p><strong>Ciblage WhatsApp :</strong> Liez toujours les appels à l'action au format direct <code className="text-orange-400 font-mono">wa.me/numéro</code> pour éliminer toute friction.</p>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-orange-500 font-bold">2.</span>
                          <p><strong>Clarté Tarifs :</strong> Afficher clairement les prix en Francs CFA (XOF) augmente les clics qualifiés de 40%.</p>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="text-orange-500 font-bold">3.</span>
                          <p><strong>Vocabulaire Local :</strong> L'intégration naturelle d'expressions chaleureuses renforce instantanément la confiance.</p>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-zinc-900 text-[10px] text-zinc-400 flex justify-between items-center font-mono">
                      <span>Proportion d'impact : Haute</span>
                      <span className="text-emerald-400">● Recommandations actives</span>
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* SUB-ROUTE 3.6: BILLING & CHECKOUT SYSTEM */}
            {currentPath === "/dashboard/billing" && (
              <BillingSystem user={user} setUser={setUser} isDarkMode={isDarkMode} />
            )}

            {/* SUB-ROUTE 3.7: USER SETTINGS */}
            {currentPath === "/dashboard/settings" && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  
                  {/* Left part: profile modifications (7 cols) */}
                  <div className="lg:col-span-7 rounded-2xl border border-slate-900 bg-slate-900/25 p-5 space-y-5 text-xs text-left">
                    <div className="flex items-center gap-2 pb-2.5 border-b border-slate-900">
                      <User className="h-4.5 w-4.5 text-amber-500" />
                      <h4 className="text-sm font-bold text-slate-100">Curation des données de votre boutique</h4>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-slate-400 font-semibold mb-1">Votre Prénom & Nom</label>
                          <input 
                            type="text" 
                            value={user.name} 
                            onChange={(e) => setUser({ ...user, name: e.target.value })}
                            className="w-full rounded-lg bg-slate-950 border border-slate-850 px-3 py-2 text-slate-200 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-400 font-semibold mb-1">E-mail de communication</label>
                          <input 
                            type="email" 
                            value={user.email} 
                            onChange={(e) => setUser({ ...user, email: e.target.value })}
                            className="w-full rounded-lg bg-slate-950 border border-slate-850 px-3 py-2 text-slate-200 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-slate-400 font-semibold mb-1">Nom commercial de l'entreprise</label>
                          <input 
                            type="text" 
                            value={user.companyName} 
                            onChange={(e) => setUser({ ...user, companyName: e.target.value })}
                            className="w-full rounded-lg bg-slate-950 border border-slate-850 px-3 py-2 text-slate-200 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-400 font-semibold mb-1">Numéro WhatsApp de réception des commandes</label>
                          <input 
                            type="text" 
                            placeholder="+221 77 123 45 67"
                            className="w-full rounded-lg bg-slate-950 border border-slate-850 px-3 py-2 text-slate-200 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <button
                          type="button"
                          onClick={() => alert("🎉 Vos paramètres ont été modifiés et enregistrés dans Dak'Content !")}
                          className="rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-4 py-2 uppercase tracking-wide"
                        >
                          Enregistrer les modifications
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right part: Developers API Keys secret tokens (5 cols) */}
                  <div className="lg:col-span-5 rounded-2xl border border-slate-900 bg-slate-950 p-5 space-y-4 text-xs text-left">
                    <div className="flex items-center gap-2 pb-2.5 border-b border-slate-900">
                      <Lock className="h-4.5 w-4.5 text-rose-500" />
                      <h4 className="text-sm font-bold text-slate-100">Clés de Sécurité & API Dak'Content</h4>
                    </div>

                    <p className="text-slate-400 leading-relaxed">
                      Si vous etes un développeur Web, vous pouvez utiliser votre propre clé d'accès API pour interfacer nos générateurs d'affiches d'Ibis dakar à vos sites e-commerce externes.
                    </p>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-slate-500 mb-1 font-mono uppercase text-[9px]">Clé API Secrète Privée :</label>
                        <div className="bg-slate-905 border border-slate-850 px-3 py-2.5 rounded-lg flex items-center justify-between font-mono text-[10px] text-slate-350 bg-slate-900">
                          <span>dk_live_•••••••••••••••••••••2026</span>
                          <span 
                            onClick={() => alert("Clé API copiée dans votre presse-papiers !")}
                            className="text-amber-500 hover:text-amber-400 cursor-pointer font-bold uppercase text-[9px]"
                          >
                            Copier la clé
                          </span>
                        </div>
                      </div>

                      <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-900 space-y-1">
                        <span className="block text-[9px] font-bold text-amber-500 uppercase tracking-wider">Note de conformité :</span>
                        <p className="text-[10px] text-slate-400">
                          Ne divulguez jamais vos identifiants d'API secrète Dak'Content en public. Votre clé d'accès Gemini est stockée de manière sécurisée et invisible côté serveur.
                        </p>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            )}

          </main>
        </div>
      )}

      {/* WAVE / ORANGE CHECKOUT INSTRUCTION POPUP MODAL */}
      {activePaymentModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-slate-950 p-6 space-y-5 text-center shadow-2xl relative">
            <button
              onClick={() => setActivePaymentModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>

            {/* Icon header of modal based on payment pathways */}
            {activePaymentModal.method === "Wave" && (
              <div className="h-14 w-14 rounded-full bg-sky-500/10 flex items-center justify-center mx-auto text-sky-400 border border-sky-500/20">
                <Smartphone className="h-7 w-7" />
              </div>
            )}
            {activePaymentModal.method === "Orange" && (
              <div className="h-14 w-14 rounded-full bg-orange-500/10 flex items-center justify-center mx-auto text-orange-400 border border-orange-500/20">
                <Smartphone className="h-7 w-7" />
              </div>
            )}
            {activePaymentModal.method === "Stripe" && (
              <div className="h-14 w-14 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto text-emerald-400 border border-emerald-500/20 animate-pulse">
                <Lock className="h-7 w-7" />
              </div>
            )}

            <div className="space-y-1">
              <h3 className="text-base font-bold text-white">Validation du Forfait {activePaymentModal.planTitle}</h3>
              <p className="text-xs text-slate-400">Paiement unique sécurisé de {activePaymentModal.price} {activePaymentModal.currency}.</p>
            </div>

            {/* Simulated instructions details of Wave checkouts */}
            <div className="rounded-xl bg-slate-900 p-4 border border-slate-810 text-xs text-slate-300 space-y-3 font-semibold text-left">
              {activePaymentModal.method === "Wave" && (
                <>
                  <p className="text-[11px] text-sky-400 uppercase font-mono tracking-wider font-extrabold">📲 Instructions de virement Wave :</p>
                  <ol className="list-decimal list-inside space-y-1.5 font-normal text-slate-300">
                    <li>Ouvrez l'application <strong className="text-sky-400">Wave Sénégal</strong> sur votre smartphone.</li>
                    <li>Scannez notre QR Code officiel de marchand ou envoyez directement au <strong className="text-sky-400">+221 77 123 45 67</strong>.</li>
                    <li>Saisissez le montant exact de <strong className="text-white">{activePaymentModal.price} FCFA</strong>.</li>
                    <li>Une fois le virement Wave complété, cliquez sur le bouton de vérification ci-dessous.</li>
                  </ol>
                </>
              )}

              {activePaymentModal.method === "Orange" && (
                <>
                  <p className="text-[11px] text-orange-400 uppercase font-mono tracking-wider font-extrabold">📲 Instructions Orange Money :</p>
                  <ol className="list-decimal list-inside space-y-1.5 font-normal text-slate-300">
                    <li>Composez le code USSD <strong className="text-orange-400">#144#</strong> ou ouvrez Orange Money.</li>
                    <li>Entrez notre numéro de marchand officiel de Dak'Content.</li>
                    <li>Validez le prélèvement de <strong className="text-white">{activePaymentModal.price} FCFA</strong> avec votre code secret.</li>
                    <li>Cliquez ci-dessous pour activer vos crédits IA immédiatement.</li>
                  </ol>
                </>
              )}

              {activePaymentModal.method === "Stripe" && (
                <div className="space-y-3 font-normal text-slate-300 text-left">
                  <p className="text-[11px] text-emerald-450 text-emerald-400 uppercase font-mono tracking-wider font-extrabold flex items-center gap-1.5 mb-1">
                    <span>🔒 Formulaire de Paiement Sécurisé :</span>
                  </p>
                  
                  <div className="space-y-2.5 text-xs">
                    <div>
                      <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Nom complet sur la carte</label>
                      <input 
                        type="text" 
                        defaultValue={user.name}
                        className="w-full rounded-lg border border-slate-800 bg-slate-950 text-white px-3 py-1.5 transition-colors focus:outline-none focus:border-emerald-500 font-sans border-slate-850"
                        placeholder="Prénoms Nom"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Numéro de Carte Bancaire</label>
                      <div className="relative">
                        <input 
                          type="text" 
                          maxLength={19}
                          placeholder="4242 •••• •••• 4242"
                          className="w-full rounded-lg border border-slate-800 bg-slate-950 text-white px-3 py-1.5 font-mono transition-colors focus:outline-none focus:border-emerald-500 font-sans border-slate-850"
                          defaultValue="4242 5678 1234 4242"
                          required
                        />
                        <span className="absolute right-3 top-1.5 text-[10px] text-emerald-450 font-bold uppercase font-sans text-emerald-400">VISA</span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Expiration</label>
                        <input 
                          type="text" 
                          maxLength={5}
                          placeholder="MM/AA"
                          className="w-full rounded-lg border border-slate-800 bg-slate-950 text-white px-3 py-1.5 font-mono transition-colors focus:outline-none focus:border-emerald-500 font-sans border-slate-850"
                          defaultValue="12/28"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Code CVC</label>
                        <input 
                          type="password" 
                          maxLength={3}
                          placeholder="•••"
                          className="w-full rounded-lg border border-slate-800 bg-slate-950 text-white px-3 py-1.5 font-mono transition-colors focus:outline-none focus:border-emerald-500 font-sans border-slate-850"
                          defaultValue="123"
                          required
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[9px] text-zinc-500 pt-1 font-sans">
                      <span className="flex items-center gap-1">🛡️ Cryptage SSL 256 bits</span>
                      <span className="text-emerald-450 text-emerald-400 font-bold">Stripe Verified ✔</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Validation action states */}
            {simulatedCheckoutSuccess ? (
              <div className="flex items-center gap-1.5 rounded-xl bg-emerald-950 border border-emerald-900 p-3 text-emerald-400 text-xs justify-center font-bold">
                <Loader2 className="h-4 w-4 animate-spin shrink-0" />
                <span>Traitement de la transaction en cours...</span>
              </div>
            ) : (
              <button
                onClick={handleSimulatePaymentProcess}
                className="w-full rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 py-3 text-xs font-black text-slate-950 uppercase tracking-widest transition-all shadow-md active:scale-95"
              >
                Vérifier & Activer mes crédits
              </button>
            )}

          </div>
        </div>
      )}

      {/* COMMAND PALETTE MODAL DIALOG (CMD+K / CTRL+K) */}
      {searchPaletteOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex justify-center pt-[15vh] p-4 font-sans">
          <div className={`w-full max-w-lg rounded-2xl border flex flex-col overflow-hidden max-h-[55vh] shadow-2xl animate-in fade-in zoom-in-95 duration-200 ${
            isDarkMode ? "border-zinc-800 bg-zinc-950 text-white" : "border-slate-200 bg-white text-slate-800"
          }`}>
            {/* Input Header */}
            <div className={`flex items-center gap-3 px-4 py-3.5 border-b ${
              isDarkMode ? "border-zinc-900 bg-zinc-900/40" : "border-slate-100 bg-slate-50/50"
            }`}>
              <Search className="h-5 w-5 text-slate-400 shrink-0" />
              <input 
                type="text"
                autoFocus
                placeholder="Rechercher des fonctionnalités, modèles, sous-pages..."
                onChange={(e) => setSearchQuery(e.target.value)}
                value={searchQuery}
                className="w-full bg-transparent text-sm focus:outline-none placeholder-slate-550 placeholder-slate-500"
              />
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase tracking-wider ${
                isDarkMode ? "bg-zinc-900 border-zinc-800 text-zinc-400" : "bg-slate-100 border-slate-200 text-slate-500"
              }`}>
                ESC
              </span>
            </div>

            {/* Scrollable results list */}
            <div className="p-2 overflow-y-auto space-y-4 text-xs text-left max-h-[40vh]">
              {/* Category of actions */}
              <div>
                <span className="block text-[10px] font-mono text-slate-500 uppercase tracking-wider px-3 mb-1 font-bold">🎯 Raccourcis de navigation</span>
                <div className="space-y-0.5">
                  {[
                    { title: "Atelier IA Créative [Campagnes d'Affiches]", path: "/dashboard/create", key: "Génération automatique d'affiches ibis dakar, vidéo mockups" },
                    { title: "Bibliothèque de mes Projets persistants", path: "/dashboard/projects", key: "Affiches téléchargées, archives sénégal campagnes" },
                    { title: "Bibliothèque de Modèles & Gabarits", path: "/dashboard/templates", key: "Forfaits, templates dak'content" },
                    { title: "Statistiques d'Impact Conversions", path: "/dashboard/analytics", key: "Graphiques recharts, clic whatsapp, wave" },
                    { title: "Mon Compte Crédit et Factures", path: "/dashboard/billing", key: "Forfait Wave, Orange Money, Stripe" },
                    { title: "Paramètres d'entreprise & Clés de Sécurité", path: "/dashboard/settings", key: "Paramètres boutique whatsapp, clé secrète" },
                  ].filter(item => 
                    searchQuery ? (item.title + item.key).toLowerCase().includes(searchQuery.toLowerCase()) : true
                  ).map((item, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setCurrentPath(item.path);
                        setSearchPaletteOpen(false);
                        setSearchQuery("");
                      }}
                      className={`w-full px-3 py-2 rounded-lg flex items-center justify-between text-left transition-colors font-sans py-2.5 ${
                        isDarkMode ? "hover:bg-zinc-900 text-zinc-200" : "hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />
                        <span>{item.title}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono select-none">Aller →</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Category of actions */}
              <div>
                <span className="block text-[10px] font-mono text-slate-500 uppercase tracking-wider px-3 mb-1 font-bold">🛡️ Actions d'environnement</span>
                <div className="space-y-0.5">
                  {[
                    { 
                      title: "Basculer le mode Sombre / Clair", 
                      action: () => setIsDarkMode(!isDarkMode), 
                      desc: "Inverser les contrastes du dashboard" 
                    },
                    { 
                      title: "Acheter un Forfait Pro (Wave/Orange/Stripe)", 
                      action: () => {
                        setCurrentPath("/dashboard/billing");
                        setSearchPaletteOpen(false);
                        setSearchQuery("");
                      }, 
                      desc: "Recharger des crédits IA directes" 
                    },
                    { 
                      title: "Fermer le menu console", 
                      action: () => setSearchPaletteOpen(false), 
                      desc: "Masquer cet overlay" 
                    }
                  ].filter(item => 
                    searchQuery ? (item.title + item.desc).toLowerCase().includes(searchQuery.toLowerCase()) : true
                  ).map((item, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        item.action();
                      }}
                      className={`w-full px-3 py-2 rounded-lg flex items-center justify-between text-left transition-colors font-sans py-2.5 ${
                        isDarkMode ? "hover:bg-zinc-900 text-zinc-200" : "hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                        <div>
                          <p className="font-semibold">{item.title}</p>
                          <p className="text-[10px] text-slate-500">{item.desc}</p>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-500 font-bold uppercase font-sans">Exécuter</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer containing hints */}
            <div className={`px-4 py-2 border-t text-[10px] text-slate-500 flex justify-between items-center bg-slate-900/10 ${
              isDarkMode ? "border-zinc-800 bg-zinc-950/60" : "border-slate-100 bg-slate-50/40"
            }`}>
              <span>Raccourci: Ctrl+K / Cmd+K</span>
              <span>Propulser par Dak'Content</span>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
