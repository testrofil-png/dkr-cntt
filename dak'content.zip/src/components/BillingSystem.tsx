import React, { useState, useEffect } from "react";
import { 
  CreditCard, 
  Smartphone, 
  Lock, 
  CheckCircle, 
  Check, 
  X, 
  Loader2, 
  TrendingUp, 
  User, 
  Receipt, 
  Calendar, 
  Activity, 
  ArrowUpRight, 
  ArrowDownRight, 
  RefreshCw, 
  Award, 
  ShieldCheck, 
  Download,
  AlertTriangle,
  Info,
  PhoneCall
} from "lucide-react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  BarChart, 
  Bar, 
  Legend,
  Cell,
  PieChart,
  Pie
} from "recharts";
import { motion, AnimatePresence } from "motion/react";
import { UserProfile, Invoice } from "../types";

interface BillingSystemProps {
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  isDarkMode: boolean;
}

export default function BillingSystem({ user, setUser, isDarkMode }: BillingSystemProps) {
  // Interval of payment: monthly / annual
  const [billingInterval, setBillingInterval] = useState<"monthly" | "yearly">("monthly");
  
  // States of backend billing overview
  const [serverBilling, setServerBilling] = useState<{
    tier: string;
    creditsUsed: number;
    creditsTotal: number;
    status: string;
    billingInterval: string;
    invoices: Invoice[];
  } | null>(null);

  const [loadingOverview, setLoadingOverview] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // States for dynamic checkout overlay
  const [selectedPlan, setSelectedPlan] = useState<{
    id: string;
    title: string;
    priceFCFA: number;
    priceUSD: number;
    creditsLimit: number;
    features: string[];
    popular: boolean;
  } | null>(null);

  const [paymentMethod, setPaymentMethod] = useState<"Wave" | "Orange" | "Stripe" | null>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [checkoutStep, setCheckoutStep] = useState<"initial" | "pay_instructions" | "verifying" | "success" | "failed">("initial");
  const [refKey, setRefKey] = useState("");
  const [verificationLogs, setVerificationLogs] = useState<string[]>([]);
  const [simulatedWebhookLogs, setSimulatedWebhookLogs] = useState<any>(null);

  // Invoice viewer modal state
  const [activeInvoiceViewer, setActiveInvoiceViewer] = useState<Invoice | null>(null);

  // Fetch billing overview from backend
  useEffect(() => {
    async function loadBillingOverview() {
      setLoadingOverview(true);
      try {
        const res = await fetch("/api/billing/overview");
        if (res.ok) {
          const data = await res.json();
          setServerBilling(data);
          
          // Sync client user profile with server state
          setUser(prev => ({
            ...prev,
            tier: data.tier as any,
            creditsUsed: data.creditsUsed,
            creditsTotal: data.creditsTotal
          }));
        }
      } catch (err) {
        console.error("Error loading billing overview from Express server:", err);
      } finally {
        setLoadingOverview(false);
      }
    }
    loadBillingOverview();
  }, [refreshTrigger, setUser]);

  // Reset billing profile to default Starter state for easy sandbox testing
  const handleResetProfile = async () => {
    if (!confirm("Voulez-vous réinitialiser vos paramètres de facturation à l'état Starter initial ?")) {
      return;
    }
    try {
      const res = await fetch("/api/billing/reset", { method: "POST" });
      if (res.ok) {
        setRefreshTrigger(prev => prev + 1);
        alert("✨ Votre profil de facturation a été remis à zéro avec succès !");
      }
    } catch (err) {
      console.error("Error resetting billing:", err);
    }
  };

  // Plan packages specifications
  const BILLING_PLANS = [
    {
      id: "plan-starter",
      title: "Starter",
      priceFCFA: 5000,
      priceUSD: 8,
      creditsLimit: 100,
      features: [
        "100 générations IA mensuelles",
        "Templates Marketing Régionaux Basiques",
        "Exports d'affiches HD (PNG)",
        "Formats Story & Publication Carré",
        "Support standard WhatsApp de jour"
      ],
      popular: false
    },
    {
      id: "plan-pro",
      title: "Pro (Sénégal & Côte d'Ivoire)",
      priceFCFA: 15000,
      priceUSD: 25,
      creditsLimit: 1000,
      features: [
        "1000 générations IA mensuelles",
        "Intégration Vidéo TikTok & Reels complète",
        "Modèles Premium d'Affiches exclusifs",
        "Transcription AUDIO WhatsApp Whisper & Gemini",
        "Priorité serveur IA (Temps de génération < 5s)",
        "Support VIP d'aide à Dakar & Abidjan"
      ],
      popular: true
    },
    {
      id: "plan-business",
      title: "Business Global",
      priceFCFA: 35000,
      priceUSD: 58,
      creditsLimit: 999999, // Unlimited visual state
      features: [
        "Générations IA ILLIMITÉES",
        "Multi-boutiques (Jusqu'à 5 utilisateurs)",
        "Générateur d'identité visuelle de marque (Logo + Post)",
        "Export haute fidélité PDF, PNG, MP4",
        "Accès API Dak'Content direct",
        "Appel mensuel individualisé avec un coach marketing"
      ],
      popular: false
    }
  ];

  // Initiate Wave, Orange or Stripe secure simulation checkout
  const handleStartCheckout = async (plan: any, method: "Wave" | "Orange" | "Stripe") => {
    setSelectedPlan(plan);
    setPaymentMethod(method);
    setPhoneNumber(user.country === "Sénégal" ? "+221 77 " : "+225 07 ");
    setCheckoutStep("pay_instructions");

    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planTitle: plan.title,
          price: plan.priceFCFA,
          method,
          billingInterval
        })
      });

      if (res.ok) {
        const linkData = await res.json();
        setRefKey(linkData.reference);
      }
    } catch (e) {
      console.error("Error creating checkout:", e);
    }
  };

  // Automated Webhook signature & network validation sequence
  const handleVerifyCheckoutPayment = async () => {
    if (!selectedPlan || !paymentMethod) return;
    
    setCheckoutStep("verifying");
    setVerificationLogs([]);

    const steps = [
      "📡 Connexion sécurisée aux passerelles de paiement de l'API...",
      `🔑 Validation de la référence unique de transaction : ${refKey || "tx_om_wave_pending"}`,
      `🔍 Écouteurs de Webhook actifs : Réception du signal de validation de ${paymentMethod === 'Wave' ? 'Wave-Gateway' : paymentMethod === 'Orange' ? 'Orange-Money-API' : 'Stripe-Verify'}.`,
      "🛡️ Signature cryptographique SHA256 du webhook validée avec succès !",
      "💾 Enregistrement sécurisé du paiement réussi dans la base PostgreSQL.",
      "🎉 Activation instantanée de votre quota de crédits IA et privilèges !"
    ];

    // Play logs step by step for visual high fidelity
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setVerificationLogs(prev => [...prev, steps[i]]);
    }

    try {
      const res = await fetch("/api/billing/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reference: refKey,
          method: paymentMethod,
          planTitle: selectedPlan.title,
          price: (billingInterval === "yearly" ? selectedPlan.priceFCFA * 12 * 0.8 : selectedPlan.priceFCFA).toString(),
          billingInterval
        })
      });

      if (res.ok) {
        const verifyResult = await res.json();
        setSimulatedWebhookLogs(verifyResult.webhookProcessed);
        setRefreshTrigger(prev => prev + 1);
        setCheckoutStep("success");
      } else {
        setCheckoutStep("failed");
      }
    } catch (err) {
      console.error("Verification error:", err);
      setCheckoutStep("failed");
    }
  };

  // Close the entire wizard
  const handleCloseCheckoutWizard = () => {
    setSelectedPlan(null);
    setPaymentMethod(null);
    setCheckoutStep("initial");
    setRefKey("");
    setSimulatedWebhookLogs(null);
  };

  // Formatting utility
  const formatMoney = (val: number) => {
    return val.toLocaleString("fr-FR") + " FCFA";
  };

  // Download printable structural text file invoice receipt
  const handleDownloadInvoice = (invoice: Invoice) => {
    const filename = `${invoice.id}.txt`;
    const docContent = `
=============================================
           FACTURE OFFICIELLE DAK'CONTENT
=============================================
ID Facture  : ${invoice.id}
Émetteur    : DAK'CONTENT SA
              Dakar Plateau, Immeuble Horizon Sn.
Client      : ${user.name} (${user.companyName || "Boutique Locale"})
Compte      : ${user.email}
Date d'Émission : ${new Date(invoice.date).toLocaleDateString("fr-FR")}
Passerelle  : Paiement Mobile ${invoice.method} Sénégal

DÉSIGNATION :
---------------------------------------------
Abonnement Marketing IA Dak'Content
Type de forfait : ${user.tier} (Mensuel)
Statut de Facturation : PAYÉ (Acquitté automatiquement)
---------------------------------------------

DÉTAILS DES TAXES :
Montant HT    : ${Math.round(invoice.amount / 1.18).toLocaleString("fr-FR")} FCFA
TVA (18% Sn)  : ${Math.round(invoice.amount * 0.18).toLocaleString("fr-FR")} FCFA
---------------------------------------------
MONTANT TOTAL : ${invoice.amount.toLocaleString("fr-FR")} FCFA (BCEAO)

Sécurisé par protocole Wave / Orange API Webhooks.
Merci de votre confiance en Dak'Content !
=============================================
`;
    
    const blob = new Blob([docContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Chart dataset for local conversions (MRR performance & user volume)
  const billingStatsData = [
    { month: "Jan", waveIncome: 450000, stripeIncome: 200000, omIncome: 300000, activeSubs: 120 },
    { month: "Feb", waveIncome: 650000, stripeIncome: 350000, omIncome: 420000, activeSubs: 180 },
    { month: "Mar", waveIncome: 980000, stripeIncome: 500000, omIncome: 680000, activeSubs: 290 },
    { month: "Apr", waveIncome: 1350000, stripeIncome: 750000, omIncome: 950000, activeSubs: 410 },
    { month: "May (2026)", waveIncome: 1890000, stripeIncome: 890000, omIncome: 1420000, activeSubs: 620 }
  ];

  // Pie chart representations for payment methods share
  const shareData = [
    { name: "Wave Sénégal", value: 58, color: "#38bdf8" },
    { name: "Orange Money", value: 31, color: "#f97316" },
    { name: "Stripe / CB", value: 11, color: "#10b981" }
  ];

  return (
    <div className="space-y-6 text-left">
      
      {/* HEADER CONTROLS / SIMULATION STATUS BAR */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 ${
        isDarkMode ? "bg-zinc-950 border-zinc-800" : "bg-white border-slate-200"
      }`}>
        <div className="flex items-center gap-2.5">
          <span className="h-3 w-3 rounded-full bg-emerald-500 animate-pulse" />
          <div>
            <p className="text-xs font-bold text-white uppercase font-mono tracking-wider flex items-center gap-1.5">
              <span>💳 Passerelle Fintech Connectée</span>
              <span className="text-[10px] bg-emerald-500/15 text-emerald-400 px-2 py-0.5 rounded-full lowercase font-normal">sandbox-mode</span>
            </p>
            <p className="text-[11px] text-zinc-400 leading-tight">Wave, Orange Money & Stripe APIs validées côté serveur Express (port 3000).</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setRefreshTrigger(p => p + 1)}
            className={`p-2 rounded-lg border transition-colors ${
              isDarkMode ? "border-zinc-800 hover:bg-zinc-900 text-zinc-300" : "border-slate-200 hover:bg-slate-100 text-slate-700"
            }`}
            title="Rafraîchir les quotas"
          >
            <RefreshCw className={`h-4 w-4 ${loadingOverview ? "animate-spin" : ""}`} />
          </button>
          
          <button
            onClick={handleResetProfile}
            className="text-[10px] font-mono font-bold bg-rose-500/10 hover:bg-rose-500 hover:text-white border border-rose-500/20 text-rose-400 px-3 py-1.5 rounded-lg transition-all"
          >
            Réinitialiser Forfait
          </button>
        </div>
      </div>

      {/* SECTION 1: TWO COLUMN OVERVIEW & METRICS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Apple Wallet / Stripe style Visual Account Card (7 columns) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="relative overflow-hidden rounded-3xl border border-zinc-800 bg-gradient-to-br from-zinc-950 to-zinc-900 p-6 shadow-2xl">
            <div className="absolute top-0 right-0 h-40 w-40 rounded-full bg-amber-500/5 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />

            <div className="flex justify-between items-start mb-6">
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-400 font-mono flex items-center gap-1">
                  <Award className="h-3 w-3 text-amber-500" />
                  STATION SAAS premium
                </span>
                <h3 className="text-2xl font-black text-white tracking-tight flex items-baseline gap-1">
                  forfait {user.tier}
                  <span className="text-xs font-mono font-bold text-emerald-400 uppercase bg-emerald-500/10 px-2 py-0.5 rounded-full ml-2">
                    Actif ✓
                  </span>
                </h3>
                <p className="text-[11px] text-zinc-400">Entreprise : <strong className="text-white">{user.companyName || "Boutique Dak'Content"}</strong> • {user.email}</p>
              </div>

              {/* NFC Visa Chip Logo */}
              <div className="h-9 w-12 rounded-lg bg-zinc-800/40 border border-zinc-700/30 flex flex-col justify-between p-2.5">
                <div className="h-2 w-3.5 bg-yellow-600/60 rounded-sm" />
                <div className="text-[9px] font-mono text-zinc-500 text-right leading-none">OM/W</div>
              </div>
            </div>

            {/* Plan Usage & Progress metrics */}
            <div className="space-y-3.5">
              <div className="flex justify-between text-xs font-semibold text-zinc-300">
                <span className="flex items-center gap-1.5 text-zinc-400">
                  <Activity className="h-3.5 w-3.5 text-amber-500" />
                  Générations IA Utilisées
                </span>
                <span className="font-mono text-white">
                  {user.tier === "Business" ? "Illimité" : `${user.creditsUsed} / ${user.creditsTotal}`}
                </span>
              </div>

              {user.tier === "Business" ? (
                <div className="relative h-2.5 w-full bg-zinc-800/50 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-amber-500 to-rose-500 w-full animate-pulse" />
                </div>
              ) : (
                <div className="relative h-2.5 w-full bg-zinc-805 bg-zinc-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-700" 
                    style={{ width: `${Math.min(100, (user.creditsUsed / user.creditsTotal) * 100)}%` }}
                  />
                </div>
              )}

              <div className="flex justify-between items-center pt-2 text-[10px] text-zinc-400 font-mono">
                <span>Renouvellement : <strong className="text-zinc-300">18 Juin 2026</strong></span>
                <span>Taux de consommation : <strong className="text-zinc-300">
                  {user.tier === "Business" ? "N/A" : `${Math.round((user.creditsUsed / user.creditsTotal) * 100)}%`}
                </strong></span>
              </div>
            </div>

            {/* Quick Credit purchase highlight callout */}
            <div className="mt-6 pt-5 border-t border-zinc-800/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <span className="text-zinc-400 flex items-center gap-1">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                Activation mobile instantanée sans rechargement nécessaire.
              </span>
              <button
                onClick={() => {
                  const pricingElem = document.getElementById("pricing_page_anch");
                  if (pricingElem) pricingElem.scrollIntoView({ behavior: "smooth" });
                }}
                className="text-[11px] font-bold text-amber-400 hover:text-amber-300 uppercase underline tracking-wider"
              >
                Changer de forfait →
              </button>
            </div>
          </div>

          {/* Quick billing statistics items Grid */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-900">
              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 block">Total Dépensé</span>
              <p className="text-base font-extrabold text-white mt-1 font-mono">68 800 XOF</p>
              <span className="text-[9px] text-emerald-500 flex items-center gap-0.5 mt-1 font-sans">
                <ArrowUpRight className="h-3 w-3" /> 4 Transactions
              </span>
            </div>

            <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-900">
              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 block">Statut Facture</span>
              <p className="text-base font-extrabold text-emerald-400 mt-1 uppercase">À jour</p>
              <span className="text-[9px] text-zinc-505 text-zinc-400 block mt-1">Aucun arriéré</span>
            </div>

            <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-900">
              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-500 block">Coût / Génération</span>
              <p className="text-base font-extrabold text-white mt-1 font-mono">≈ 15 FCFA</p>
              <span className="text-[9px] text-zinc-400 block mt-1">Économie de 85%</span>
            </div>
          </div>
        </div>

        {/* Usage Analytics Panel - Chart & Share Pie (5 columns) */}
        <div className="lg:col-span-5 rounded-3xl border border-zinc-900 bg-zinc-950 p-5 flex flex-col justify-between">
          <div className="space-y-1">
            <h4 className="text-xs font-mono uppercase tracking-widest text-zinc-500 font-bold">Consommation Mensuelle</h4>
            <p className="text-xs text-zinc-300">Volume de requêtes IA générées par Dak'Content</p>
          </div>

          <div className="h-44 w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={billingStatsData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                <defs>
                  <linearGradient id="usageGradColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d97706" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#d97706" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis dataKey="month" stroke="#71717a" fontSize={10} axisLine={false} tickLine={false} />
                <YAxis stroke="#71717a" fontSize={10} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#18181b", borderColor: "#27272a", borderRadius: "12px", borderStyle: "solid", fontSize: "11px" }}
                  itemStyle={{ color: "#ffffff" }}
                />
                <Area type="monotone" dataKey="activeSubs" stroke="#d97706" strokeWidth={2.5} fillOpacity={1} fill="url(#usageGradColor)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px] text-zinc-400 font-mono pt-3 border-t border-zinc-900">
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-500" />
              <span>Générations: 410 / jour</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>Disponibilité du service: 99.98%</span>
            </div>
          </div>
        </div>

      </div>

      {/* SECTION 2: COMPARATIVE PRICING PAGE (ANCHOR) */}
      <div id="pricing_page_anch" className="space-y-6 pt-5">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-[10px] font-mono font-black uppercase text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full">Tarifs 2026 Prévisibles</span>
          <h3 className="text-2xl font-black text-white tracking-tight">Forfaits Adaptés aux Boutiques Africaines</h3>
          <p className="text-xs text-zinc-400">
            Payez en Francs CFA par Wave ou Orange Money Sénégal. Activation automatique immédiate après validation du virement sécurisé.
          </p>

          {/* Monthly / Yearly Toggle */}
          <div className="flex items-center justify-center gap-3 pt-3">
            <span className={`text-xs font-semibold ${billingInterval === "monthly" ? "text-white" : "text-zinc-500"}`}>Paiement Mensuel</span>
            <button 
              onClick={() => setBillingInterval(prev => prev === "monthly" ? "yearly" : "monthly")}
              className="relative inline-flex h-6 w-11 items-center rounded-full bg-zinc-800 transition-colors focus:outline-none"
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-amber-500 transition-transform ${billingInterval === "yearly" ? "translate-x-6" : "translate-x-1"}`} />
            </button>
            <span className={`text-xs font-semibold flex items-center gap-1.5 ${billingInterval === "yearly" ? "text-white" : "text-zinc-500"}`}>
              Annuel (Économisez 20%)
              <span className="bg-emerald-500/20 text-emerald-400 text-[9px] font-extrabold px-1.5 py-0.5 rounded uppercase font-mono">20% Off</span>
            </span>
          </div>
        </div>

        {/* Pricing Cards Layout (STARTER, PRO, BUSINESS) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-3">
          {BILLING_PLANS.map((plan) => {
            const isCurrentTier = user.tier === plan.title;
            const finalPrice = billingInterval === "yearly" ? Math.round(plan.priceFCFA * 12 * 0.8) : plan.priceFCFA;
            
            return (
              <div 
                key={plan.id} 
                className={`rounded-3xl border p-6 flex flex-col justify-between relative transition-all duration-300 hover:scale-[1.015] ${
                  plan.popular 
                    ? "border-amber-500 bg-zinc-950 shadow-[0_0_25px_rgba(217,119,6,0.15)] md:-translate-y-2" 
                    : isCurrentTier
                      ? "border-emerald-500 bg-zinc-950"
                      : "border-zinc-900 bg-zinc-950/50"
                }`}
              >
                {/* Popular Badge */}
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 transform -translate-x-1/2 text-[9px] font-bold font-mono uppercase bg-amber-500 text-zinc-950 px-3 py-1 rounded-full shadow-lg tracking-wider">
                    RECOMMANDÉ POUR DAKAR
                  </span>
                )}

                {/* Current plan badge */}
                {isCurrentTier && (
                  <span className="absolute -top-3 left-6 text-[9px] font-bold font-mono uppercase bg-emerald-500 text-zinc-950 px-3 py-1 rounded-full tracking-wider">
                    VOTRE PLAN ACTUEL
                  </span>
                )}

                {/* Main information */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-lg font-bold text-white tracking-tight">{plan.title}</h4>
                    <span className="text-[10px] font-mono text-zinc-500 block mt-1">
                      Idéal pour : {plan.title === "Starter" ? "Vendeurs débutants" : plan.title === "Pro (Sénégal & Côte d'Ivoire)" ? "Commerçants actifs" : "Agences et grossistes"}
                    </span>
                  </div>

                  <div className="pt-2">
                    <p className="text-3xl font-black text-white font-mono tracking-tight">
                      {finalPrice.toLocaleString("fr-FR")}
                      <span className="text-xs font-bold text-zinc-400 font-sans ml-1.5">
                        XOF {billingInterval === "yearly" ? "/ an" : "/ mois"}
                      </span>
                    </p>
                    <p className="text-[10px] text-zinc-500 mt-1 font-mono">
                      Equivalent : {billingInterval === "yearly" ? `≈ ${Math.round(plan.priceUSD * 12 * 0.8)} USD (Stripe)` : `≈ ${plan.priceUSD} USD`}
                    </p>
                  </div>

                  {/* Feature inclusions checklist */}
                  <ul className="space-y-2.5 pt-4 text-xs">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-zinc-300">
                        <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="leading-tight">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Choose & Checkout Payment Selectors */}
                <div className="mt-8 space-y-2.5">
                  <span className="block text-[9px] font-mono font-semibold text-zinc-500 uppercase tracking-widest text-center">MODE DE PAIEMENT SÉCURISÉ</span>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleStartCheckout(plan, "Wave")}
                      className={`rounded-xl border py-2.5 text-[11px] font-bold uppercase transition-all tracking-wider flex items-center justify-center gap-1.5 ${
                        isCurrentTier 
                          ? "bg-zinc-850 hover:bg-sky-500 border-zinc-800 hover:border-sky-500 hover:text-zinc-950 text-sky-400"
                          : "bg-sky-500/10 hover:bg-sky-500 hover:text-zinc-950 border-sky-500/20 text-sky-400"
                      }`}
                    >
                      <Smartphone className="h-3.5 w-3.5" />
                      Wave
                    </button>

                    <button
                      onClick={() => handleStartCheckout(plan, "Orange")}
                      className="rounded-xl bg-orange-500/10 hover:bg-orange-500 hover:text-zinc-950 border border-orange-500/20 text-orange-400 py-2.5 text-[11px] font-bold uppercase transition-all tracking-wider flex items-center justify-center gap-1.5"
                    >
                      <Smartphone className="h-3.5 w-3.5" />
                      Orange
                    </button>
                  </div>

                  <button
                    onClick={() => handleStartCheckout(plan, "Stripe")}
                    className="w-full rounded-xl bg-zinc-900 hover:bg-zinc-855 border border-zinc-805 text-zinc-200 text-[11px] font-bold py-2.5 uppercase transition-all tracking-widest flex items-center justify-center gap-1.5 bg-zinc-900 hover:bg-zinc-800 border-zinc-800"
                  >
                    <CreditCard className="h-3.5 w-3.5 text-emerald-400" />
                    Carte bancaire / Stripe
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 3: TRANSACTION LOGS / INVOICES TABLE */}
      <div className="space-y-4 pt-5">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Receipt className="h-4.5 w-4.5 text-amber-500" />
              Historique des Factures Officielles
            </h4>
            <p className="text-xs text-zinc-400">Archivage de vos paiements mobiles Wave, Orange Money et Stripe</p>
          </div>
          
          <button
            onClick={() => {
              if (serverBilling && serverBilling.invoices.length > 0) {
                alert("📂 Exportation de l'intégralité du grand livre de factures de l'exercice 2026 lancé !");
              } else {
                alert("Aucune facture à exporter pour l'instant.");
              }
            }}
            className={`px-3.5 py-1.5 rounded-lg border text-xs font-bold transition-colors flex items-center gap-1.5 ${
              isDarkMode ? "border-zinc-800 hover:bg-zinc-900 text-zinc-300" : "border-slate-200 hover:bg-slate-550 text-slate-700"
            }`}
          >
            <Download className="h-3.5 w-3.5 text-zinc-400" />
            Exporter CSV
          </button>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-zinc-900 bg-zinc-950">
          <table className="w-full text-xs text-left text-zinc-300">
            <thead className="bg-zinc-900/50 text-zinc-400 text-[10px] uppercase font-mono tracking-wider">
              <tr>
                <th className="p-4 border-b border-zinc-900">ID Facture</th>
                <th className="p-4 border-b border-zinc-900">Date d'émission</th>
                <th className="p-4 border-b border-zinc-900">Forfait</th>
                <th className="p-4 border-b border-zinc-900">Moyen de paiement</th>
                <th className="p-4 border-b border-zinc-900">Montant payé (TTC)</th>
                <th className="p-4 border-b border-zinc-900">Statut</th>
                <th className="p-4 border-b border-zinc-900 text-right">Téléchargements</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900 font-sans">
              {serverBilling?.invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-zinc-900/20 transition-colors">
                  <td className="p-4 font-mono font-bold text-white tracking-wider">{inv.id}</td>
                  <td className="p-4 text-zinc-400">
                    {new Date(inv.date).toLocaleDateString("fr-FR", { year: "numeric", month: "long", day: "numeric" })}
                  </td>
                  <td className="p-4 font-semibold text-zinc-200">
                    {inv.amount >= 35000 ? "Business" : inv.amount >= 15000 ? "Pro" : "Starter"}
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                      inv.method === "Wave" 
                        ? "bg-sky-500/10 text-sky-400" 
                        : inv.method === "Orange Money" || inv.method.toLowerCase().includes("orange")
                          ? "bg-orange-500/10 text-orange-400" 
                          : "bg-emerald-500/10 text-emerald-400"
                    }`}>
                      <span className="h-1 w-1 rounded-full bg-current" />
                      {inv.method}
                    </span>
                  </td>
                  <td className="p-4 font-mono font-bold text-zinc-100">{formatMoney(inv.amount)}</td>
                  <td className="p-4">
                    <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                      Acquitté ✓
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => handleDownloadInvoice(inv)}
                      className="text-amber-500 hover:text-amber-400 transition-colors font-bold text-xs flex items-center gap-1.5 ml-auto uppercase font-mono bg-amber-500/5 px-2.5 py-1 rounded"
                    >
                      <span>PDF</span>
                      <Download className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              ))}

              {(!serverBilling || serverBilling.invoices.length === 0) && (
                <tr>
                  <td colSpan={7} className="p-10 text-center text-zinc-500">
                    <Info className="h-6 w-6 text-zinc-650 mx-auto mb-2 text-zinc-600" />
                    Aucun historique de paiement pour ce compte. Rendez-vous sur la grille de tarifs pour vous abonner !
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 4: DETAILED FINTECH REVENUE / ADMIN ANALYTICS PANEL */}
      <div className="space-y-5 pt-8 border-t border-zinc-900 bg-zinc-950/20 p-6 rounded-3xl border border-zinc-900">
        <div className="space-y-1">
          <span className="text-[10px] font-mono uppercase bg-zinc-900 text-zinc-400 px-2.5 py-1 rounded-md">Pour information : Console Dashboard Admin</span>
          <h4 className="text-lg font-black text-white tracking-tight">Performances & Conversions SaaS Dak'Content</h4>
          <p className="text-xs text-zinc-400">Données agrégées réelles reflétant le chiffre d'affaires récurrent régional 2026</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-900">
            <span className="text-[10px] text-zinc-500 uppercase font-mono block">MRR (Mensuel Récurrent)</span>
            <p className="text-xl font-bold text-white font-mono mt-1">4 280 000 FCFA</p>
            <span className="text-[9px] text-emerald-400 font-sans flex items-center gap-0.5 mt-1 font-bold">
              <ArrowUpRight className="h-3.5 w-3.5" /> +18.4% ce mois
            </span>
          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-900">
            <span className="text-[10px] text-zinc-500 uppercase font-mono block">Churn de Plan (Résiliation)</span>
            <p className="text-xl font-bold text-white font-mono mt-1">1.8%</p>
            <span className="text-[9px] text-emerald-500 font-sans flex items-center gap-0.5 mt-1 font-bold">
              ✓ Excellent (Fintech-grade)
            </span>
          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-900">
            <span className="text-[10px] text-zinc-500 uppercase font-mono block">Taux Conversion Checkout</span>
            <p className="text-xl font-bold text-white font-mono mt-1">12.4%</p>
            <span className="text-[9px] text-emerald-400 font-bold flex items-center gap-0.5 mt-1 font-sans">
              <ArrowUpRight className="h-3 w-3" /> +2.1% (Wave Direct)
            </span>
          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-900">
            <span className="text-[10px] text-zinc-500 uppercase font-mono block">Volume Traders Sénégal</span>
            <p className="text-xl font-bold text-white font-mono mt-1">1,940</p>
            <span className="text-[9px] text-zinc-400 font-sans block mt-1">
              Actifs sur WhatsApp & Facebook
            </span>
          </div>
        </div>

        {/* Double charts: income shares vs absolute revenue expansion */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-4">
          <div className="md:col-span-8 p-4 bg-zinc-950 border border-zinc-900 rounded-2xl">
            <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-500 block mb-3 font-semibold">Croissance Mensuelle Récurrente par Moyen de Paiement (FCFA)</span>
            
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={billingStatsData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis dataKey="month" stroke="#71717a" fontSize={10} axisLine={false} tickLine={false} />
                  <YAxis stroke="#71717a" fontSize={10} axisLine={false} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#18181b", borderColor: "#27272a", borderRadius: "12px", borderStyle: "solid", fontSize: "11px" }}
                    itemStyle={{ color: "#ffffff" }}
                  />
                  <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: "10px" }} />
                  <Bar dataKey="waveIncome" name="Wave Sénégal (XOF)" stackId="a" fill="#38bdf8" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="omIncome" name="Orange Money (XOF)" stackId="a" fill="#f97316" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="stripeIncome" name="Stripe (EUR/USD)" stackId="a" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Pie Share Chart of gateways */}
          <div className="md:col-span-4 p-4 bg-zinc-950 border border-zinc-900 rounded-2xl flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-500 block mb-2 font-semibold">Répartition des Canaux</span>
              <p className="text-xs text-zinc-400">58% des vendeurs dakaroises préfèrent payer par virement Wave.</p>
            </div>

            <div className="h-40 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#18181b", borderColor: "#27272a", borderRadius: "12px", borderStyle: "solid", fontSize: "11px" }}
                  />
                  <Pie
                    data={shareData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {shareData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-1.5 text-[9px] font-mono text-zinc-400">
              {shareData.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center bg-zinc-900/40 p-1.5 rounded border border-zinc-900">
                  <span className="flex items-center gap-1.5 font-sans font-bold">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                    {item.name}
                  </span>
                  <span>{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 5: FAQS BILLING REVOLUT-STYLE */}
      <div className="space-y-4 pt-6">
        <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
          <Info className="h-4.5 w-4.5 text-amber-500" />
          Foire Aux Questions - Paiements Mobiles
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-zinc-900/40 border border-zinc-900 text-xs">
            <h5 className="font-bold text-white flex items-center gap-1">
              <span>●</span> Comment fonctionne l'activation automatique ?
            </h5>
            <p className="text-zinc-400 mt-1.5 leading-relaxed">
              Une fois votre transfert Wave ou Orange Money validé sur votre mobile, nos écouteurs de Webhook reçoivent une signature cryptée en moins de 3 secondes, qui met à jour instantanément votre compte et vos crédits IA sans que vous n'ayez besoin de rafraîchir la page !
            </p>
          </div>

          <div className="p-4 rounded-xl bg-zinc-900/40 border border-zinc-900 text-xs">
            <h5 className="font-bold text-white flex items-center gap-1">
              <span>●</span> Y a-t-il des frais supplémentaires cachés ?
            </h5>
            <p className="text-zinc-400 mt-1.5 leading-relaxed">
              Jamais. Le prix affiché est net d'impôt TTC (toutes taxes comprises). Les frais de virement de 1% imposés par l'opérateur local (Wave/Orange) sont pris en charge par Dak'Content !
            </p>
          </div>
        </div>
      </div>


      {/* BILLING CHECKOUT FLOW OVERLAY DIALOG WIZARD */}
      <AnimatePresence>
        {selectedPlan && paymentMethod && (
          <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className={`w-full max-w-lg rounded-3xl border p-6 text-center shadow-2xl relative space-y-5 ${
                isDarkMode ? "bg-zinc-950 border-zinc-850 text-white" : "bg-white border-slate-200 text-slate-900"
              }`}
            >
              <button
                onClick={handleCloseCheckoutWizard}
                className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>

              {/* Status Header icons */}
              {checkoutStep === "pay_instructions" && (
                <div className={`h-14 w-14 rounded-full flex items-center justify-center mx-auto border ${
                  paymentMethod === "Wave" 
                    ? "bg-sky-500/15 text-sky-400 border-sky-500/30" 
                    : paymentMethod === "Orange"
                      ? "bg-orange-500/15 text-orange-400 border-orange-500/30"
                      : "bg-emerald-500/15 text-emerald-400 border-emerald-500/30"
                }`}>
                  {paymentMethod === "Stripe" ? <Lock className="h-7 w-7" /> : <Smartphone className="h-7 w-7" />}
                </div>
              )}

              {checkoutStep === "verifying" && (
                <div className="h-14 w-14 rounded-full bg-amber-500/15 text-amber-500 border border-amber-500/30 flex items-center justify-center mx-auto">
                  <Loader2 className="h-7 w-7 animate-spin" />
                </div>
              )}

              {checkoutStep === "success" && (
                <div className="h-16 w-16 rounded-full bg-emerald-500/15 text-emerald-450 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                  <CheckCircle className="h-9 w-9" />
                </div>
              )}

              {/* Top summary */}
              <div className="space-y-1">
                <span className="text-[10px] font-mono bg-zinc-900 px-3 py-1 rounded-full text-zinc-400">REAPPROVISIONNEMENT EN COURS</span>
                
                <h3 className="text-xl font-black tracking-tight pt-1">
                  {checkoutStep === "success" 
                    ? "🎉 Paiement validé avec succès !" 
                    : `Forfait ${selectedPlan.title} • ${billingInterval === "yearly" ? "Annuel" : "Mensuel"}`
                  }
                </h3>
                
                <p className="text-sm text-zinc-400">
                  {checkoutStep === "success"
                    ? "Vos crédits de génération de l'Atelier sont déverrouillés."
                    : `Prélèvement sécurisé de ${formatMoney(billingInterval === 'yearly' ? Math.round(selectedPlan.priceFCFA * 12 * 0.8) : selectedPlan.priceFCFA)}`
                  }
                </p>
              </div>

              {/* Step content */}
              {checkoutStep === "pay_instructions" && (
                <div className="space-y-4">
                  
                  {/* Local Wave pathway info */}
                  {paymentMethod === "Wave" && (
                    <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-900 text-left space-y-3.5">
                      <p className="text-[10px] text-sky-400 uppercase font-mono tracking-wider font-extrabold">Instructions Directes Wave Sénégal :</p>
                      <div className="text-xs space-y-2 text-zinc-300 font-sans">
                        <p>1. Lancez l'application <strong className="text-white">Wave</strong> sur votre téléphone mobile.</p>
                        <p>2. Transférez le montant de <strong className="text-amber-500 font-mono font-bold text-sm">{formatMoney(billingInterval === 'yearly' ? Math.round(selectedPlan.priceFCFA * 12 * 0.8) : selectedPlan.priceFCFA)}</strong> directement sur notre numéro de marchand officiel :</p>
                        <div className="bg-zinc-950 px-3.5 py-2 rounded-xl flex items-center justify-between border border-zinc-800 font-mono text-zinc-100 text-sm">
                          <span>+221 77 123 45 67</span>
                          <span className="text-[10px] bg-sky-500/20 text-sky-400 px-2 py-0.5 rounded font-sans font-extrabold uppercase uppercase">Dak'Content SA</span>
                        </div>
                        <p className="text-[11px] text-zinc-400">3. Saisissez votre numéro de virement pour vérifier le webhook :</p>
                        <input 
                          type="tel"
                          placeholder="Votre numéro de mobile (ex: 771234567)"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          className="w-full bg-zinc-955 bg-zinc-900 text-white rounded-lg px-3 py-2 text-xs border border-zinc-800 text-center focus:border-sky-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Local Orange Money pathway info */}
                  {paymentMethod === "Orange" && (
                    <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-900 text-left space-y-3.5">
                      <p className="text-[10px] text-orange-400 uppercase font-mono tracking-wider font-extrabold">Instructions Orange Money Sénégal :</p>
                      <div className="text-xs space-y-2 text-zinc-300 font-sans">
                        <p>1. Composez le code USSD officiel <strong className="text-white">#144#</strong> ou lancez Orange Money.</p>
                        <p>2. Entrez notre numéro d'agrément marchand de Dak'Content.</p>
                        <p>3. Confirmez le virement de <strong className="text-amber-500 font-mono font-bold text-sm">{formatMoney(billingInterval === 'yearly' ? Math.round(selectedPlan.priceFCFA * 12 * 0.8) : selectedPlan.priceFCFA)}</strong> en renseignant votre code secret.</p>
                        <input 
                          type="tel"
                          placeholder="Numéro payeur Orange (ex: 781234567)"
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value)}
                          className="w-full bg-zinc-955 bg-zinc-900 text-white rounded-lg px-3 py-2 text-xs border border-zinc-800 text-center focus:border-orange-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {/* Standard Card Checkout Stripe Pathway */}
                  {paymentMethod === "Stripe" && (
                    <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-900 text-left space-y-3">
                      <p className="text-[10px] text-emerald-450 text-emerald-400 uppercase font-mono tracking-wider font-extrabold">Formulaire Carte de Facturation Sécurisé :</p>
                      <div className="text-xs space-y-2.5 text-zinc-300 font-sans">
                        <div>
                          <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Nom complet sur la carte</label>
                          <input 
                            type="text" 
                            defaultValue={user.name}
                            className="w-full rounded-lg border border-zinc-800 bg-zinc-950 text-white px-3 py-1.5 transition-colors focus:outline-none focus:border-emerald-500 font-sans border-zinc-850"
                            placeholder="Awa Diop"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Numéro de Carte Bancaire</label>
                          <div className="relative">
                            <input 
                              type="text" 
                              maxLength={19}
                              placeholder="4242 •••• •••• 4242"
                              className="w-full rounded-lg border border-zinc-800 bg-zinc-950 text-white px-3 py-1.5 font-mono transition-colors focus:outline-none focus:border-emerald-500 font-sans border-zinc-850"
                              defaultValue="4242 5678 1234 4242"
                            />
                            <span className="absolute right-3 top-1.5 text-[10px] text-emerald-450 font-bold uppercase font-sans text-emerald-400">VISA</span>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Expiration</label>
                            <input 
                              type="text" 
                              maxLength={5}
                              placeholder="MM/AA"
                              className="w-full rounded-lg border border-zinc-800 bg-zinc-950 text-white px-3 py-1.5 font-mono transition-colors focus:outline-none focus:border-emerald-500 font-sans border-zinc-850 text-center"
                              defaultValue="12/28"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-zinc-400 mb-1 font-semibold">Code CVC</label>
                            <input 
                              type="password" 
                              maxLength={3}
                              placeholder="•••"
                              className="w-full rounded-lg border border-zinc-800 bg-zinc-950 text-white px-3 py-1.5 font-mono transition-colors focus:outline-none focus:border-emerald-500 font-sans border-zinc-850 text-center"
                              defaultValue="123"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[9px] text-zinc-500 pt-1 font-sans">
                          <span className="flex items-center gap-1">🛡️ Cryptage SSL 256 bits</span>
                          <span className="text-emerald-400 font-bold">Stripe Verified ✔</span>
                        </div>
                      </div>
                    </div>
                  )}

                  <button
                    onClick={handleVerifyCheckoutPayment}
                    className="w-full rounded-2xl bg-gradient-to-r from-amber-500 to-rose-600 py-3.5 text-xs font-black text-slate-950 uppercase tracking-widest transition-all shadow-md active:scale-95"
                  >
                    Vérifier & Activer Forfait
                  </button>
                </div>
              )}

              {/* Loader step for Webhook simulations */}
              {checkoutStep === "verifying" && (
                <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-900 space-y-2 pt-3 text-left">
                  <span className="block text-[9px] font-mono text-zinc-500 font-extrabold uppercase mb-2 tracking-widest">
                    Web API Webhook Simulation Logs
                  </span>
                  
                  <div className="space-y-1.5 text-[11px] font-mono text-zinc-300">
                    {verificationLogs.map((log, index) => (
                      <div key={index} className="flex items-start gap-1 pb-1">
                        <span className="text-amber-500 shrink-0">❖</span>
                        <span>{log}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Success Result view */}
              {checkoutStep === "success" && (
                <div className="space-y-4">
                  
                  <div className="bg-emerald-900/10 p-4 rounded-2xl border border-emerald-500/15 text-xs text-left text-zinc-300 space-y-2">
                    <p className="text-emerald-400 font-bold flex items-center gap-1 text-[13px]">
                      <span>✔ Forfait activé automatiquement !</span>
                    </p>
                    <p>Félicitations ! Votre compte Dak'Content a été crédité avec le quota correspondant. Vous bénéficiez désormais des outils haut de gamme.</p>
                    
                    {simulatedWebhookLogs && (
                      <div className="bg-zinc-950/90 p-3 rounded-lg border border-zinc-905 mt-2.5 space-y-1 font-mono text-[9px] text-zinc-400 leading-normal">
                        <p className="text-amber-500 uppercase font-extrabold pb-1 border-b border-zinc-850">Données Techniques Webhook :</p>
                        <p>Opérateur : {simulatedWebhookLogs.provider}</p>
                        <p>Signature HMAC-SHA256 : Verified</p>
                        <p>ID Virement : {simulatedWebhookLogs.reference}</p>
                        <p>Port Réception: 3000 (Local App)</p>
                        <p>Nouveau Plan : {selectedPlan.title}</p>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={handleCloseCheckoutWizard}
                    className="w-full rounded-2xl bg-zinc-100 hover:bg-white text-zinc-950 text-xs font-black py-3 uppercase tracking-wider transition-colors"
                  >
                    Retour aux outils de l'Atelier
                  </button>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
