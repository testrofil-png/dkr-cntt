import React, { useState } from "react";
import { 
  Download, 
  Smartphone, 
  Tv, 
  Layout, 
  Palette, 
  Type, 
  RefreshCw, 
  CheckCircle2, 
  Image as ImageIcon,
  Flame
} from "lucide-react";
import { PosterLayout } from "../types";

interface PosterCanvasProps {
  layout: PosterLayout;
  imageUrl?: string;
  onUpdateLayout: (updated: PosterLayout) => void;
}

interface ColorPalette {
  name: string;
  source: string;
  bgColor: string;
  accentColor: string;
}

const WEST_AFRICAN_PALETTES: ColorPalette[] = [
  {
    name: "Dakar Solaire",
    source: "Sénégal • Chaleur solar, or & cannelle",
    bgColor: "#292524", // Deep warm slate-stone
    accentColor: "#f97316", // Solar bright orange
  },
  {
    name: "Indigo Bamako",
    source: "Mali • Boubou indigo traditionnel",
    bgColor: "#111827", // Rich dark gray-indigo
    accentColor: "#06b6d4", // Bamako sky cyan
  },
  {
    name: "Terre de Korhogo",
    source: "Côte d'Ivoire • Argile sacrée & ocre",
    bgColor: "#1c1917", // Charcoal background
    accentColor: "#ea580c", // Terracotta clay
  },
  {
    name: "Kente Royal",
    source: "Ghana/Togo • Prestige & paillettes d'or",
    bgColor: "#18181b", // Elegant pure zinc black
    accentColor: "#eab308", // Kente imperial gold
  },
  {
    name: "Faso Dan Fani",
    source: "Burkina • Émeraude & drapeau de lutte",
    bgColor: "#022c22", // Forest dark green
    accentColor: "#ef4444", // Patriots crimson red
  },
  {
    name: "Latérite du Sine",
    source: "Sahel • Latérite rouge & paille sèche",
    bgColor: "#451a03", // Deep earth warm brown
    accentColor: "#facc15", // Dry grass yellow
  }
];

const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    img.src = src;
  });
};

const drawRoundedRect = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) => {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
};

export default function PosterCanvas({ 
  layout, 
  imageUrl,
  onUpdateLayout 
}: PosterCanvasProps) {
  const [format, setFormat] = useState<"square" | "story" | "landscape">("story");
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Default beautiful stock fallback products matching African SaaS PME needs if none is uploaded
  const displayImage = imageUrl || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600";

  const handleTextChange = (field: keyof PosterLayout, val: string) => {
    onUpdateLayout({
      ...layout,
      [field]: val
    });
  };

  const handleDownload = async () => {
    setDownloading(true);
    setDownloadProgress(10);
    setDownloadSuccess(false);

    try {
      const canvas = document.createElement("canvas");
      const isStory = format === "story";
      const isSquare = format === "square";
      const isLandscape = format === "landscape";

      let width = 1080;
      let height = 1920;

      if (isSquare) {
        width = 1200;
        height = 1200;
      } else if (isLandscape) {
        width = 1920;
        height = 1080;
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Could not construct 2D context");

      setDownloadProgress(30);

      // Coordinates configuration
      let imgX = 90;
      let imgY = 220;
      let imgW = 900;
      let imgH = 1050;

      let titleY = 1420;
      let subtitleY = 1510;
      let ctaY = 1660;
      let watermarkY = 1820;

      if (isSquare) {
        imgX = 120;
        imgY = 120;
        imgW = 960;
        imgH = 680;
        
        titleY = 910;
        subtitleY = 980;
        ctaY = 1080;
        watermarkY = 1150;
      } else if (isLandscape) {
        imgX = 460;
        imgY = 100;
        imgW = 1000;
        imgH = 550;
        
        titleY = 750;
        subtitleY = 820;
        ctaY = 920;
        watermarkY = 1010;
      }

      // Step 1: Background color
      ctx.fillStyle = layout.bgColor;
      ctx.fillRect(0, 0, width, height);

      // Overlay Radial glow
      const radialGradient = ctx.createRadialGradient(
        width / 2, 0, 50,
        width / 2, height / 2, Math.max(width, height)
      );
      radialGradient.addColorStop(0, "rgba(255, 255, 255, 0.08)");
      radialGradient.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = radialGradient;
      ctx.fillRect(0, 0, width, height);

      setDownloadProgress(50);

      // Step 2: Load and draw the image safely
      try {
        const img = await loadImage(displayImage);
        
        // Draw image drop shadow
        ctx.save();
        drawRoundedRect(ctx, imgX, imgY, imgW, imgH, 20);
        ctx.fillStyle = "rgba(0,0,0,0.4)";
        ctx.shadowColor = "rgba(0, 0, 0, 0.45)";
        ctx.shadowBlur = 30;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 15;
        ctx.fill();
        ctx.restore();

        // Draw the image clipped
        ctx.save();
        drawRoundedRect(ctx, imgX, imgY, imgW, imgH, 20);
        ctx.clip();

        const imgRatio = img.width / img.height;
        const destRatio = imgW / imgH;
        let sWidth = img.width;
        let sHeight = img.height;
        let sx = 0;
        let sy = 0;

        if (imgRatio > destRatio) {
          sWidth = img.height * destRatio;
          sx = (img.width - sWidth) / 2;
        } else {
          sHeight = img.width / destRatio;
          sy = (img.height - sHeight) / 2;
        }

        ctx.drawImage(img, sx, sy, sWidth, sHeight, imgX, imgY, imgW, imgH);
        
        // Gradient fade on top of the image
        const imgGradient = ctx.createLinearGradient(imgX, imgY + imgH * 0.5, imgX, imgY + imgH);
        imgGradient.addColorStop(0, "rgba(0, 0, 0, 0)");
        imgGradient.addColorStop(1, "rgba(0, 0, 0, 0.85)");
        ctx.fillStyle = imgGradient;
        ctx.fillRect(imgX, imgY + imgH * 0.5, imgW, imgH * 0.5);

        ctx.restore();

        // White border
        ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
        ctx.lineWidth = 4;
        ctx.save();
        drawRoundedRect(ctx, imgX, imgY, imgW, imgH, 20);
        ctx.stroke();
        ctx.restore();

      } catch (imageErr) {
        console.warn("CORS or Image Load error, fallback to flat geometric design block:", imageErr);
        ctx.save();
        drawRoundedRect(ctx, imgX, imgY, imgW, imgH, 20);
        const fallbackGrad = ctx.createLinearGradient(imgX, imgY, imgX + imgW, imgY + imgH);
        fallbackGrad.addColorStop(0, "rgba(255,255,255,0.06)");
        fallbackGrad.addColorStop(1, "rgba(255,255,255,0.01)");
        ctx.fillStyle = fallbackGrad;
        ctx.fill();
        
        ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
        ctx.lineWidth = 4;
        ctx.stroke();

        ctx.fillStyle = "rgba(255,255,255,0.2)";
        ctx.font = "bold 130px Inter, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("🛒", imgX + imgW / 2, imgY + imgH / 2);
        ctx.restore();
      }

      setDownloadProgress(70);

      // Step 3: Draw Bottom black overlay gradient
      const footerGradient = ctx.createLinearGradient(0, height * 0.55, 0, height);
      footerGradient.addColorStop(0, "rgba(9, 9, 11, 0)");
      footerGradient.addColorStop(0.4, "rgba(9, 9, 11, 0.7)");
      footerGradient.addColorStop(0.8, "rgba(9, 9, 11, 0.98)");
      footerGradient.addColorStop(1, "rgba(9, 9, 11, 1)");
      ctx.fillStyle = footerGradient;
      ctx.fillRect(0, height * 0.55, width, height * 0.45);

      // Step 4: Top Badge (if badgeText exists)
      if (layout.badgeText) {
        ctx.save();
        ctx.font = "bold 24px Inter, system-ui, sans-serif";
        const textWidth = ctx.measureText(layout.badgeText.toUpperCase()).width;
        const paddingX = 32;
        const paddingY = 16;
        const badgeW = textWidth + paddingX * 2;
        const badgeH = 24 + paddingY * 2;
        const badgeX = isLandscape ? 460 : 90;
        const badgeY = isLandscape ? 100 : 220;

        ctx.shadowColor = "rgba(0, 0, 0, 0.35)";
        ctx.shadowBlur = 15;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 6;
        drawRoundedRect(ctx, badgeX - 25, badgeY - 20, badgeW, badgeH, 28);
        ctx.fillStyle = layout.accentColor;
        ctx.fill();
        ctx.restore();

        // Badge Text
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 20px Inter, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(
          layout.badgeText.toUpperCase(), 
          badgeX - 25 + badgeW / 2, 
          badgeY - 20 + badgeH / 2 + 1
        );
      }

      // Step 5: Draw Title Text (centered)
      ctx.fillStyle = "#FFFFFF";
      let titleFontSize = isSquare ? 42 : isLandscape ? 44 : 52;
      ctx.font = `bold ${titleFontSize}px Inter, system-ui, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      const titleText = (layout.title || "TITRE DE L'AFFICHE").toUpperCase();
      while (ctx.measureText(titleText).width > width - 120 && titleFontSize > 24) {
        titleFontSize -= 2;
        ctx.font = `bold ${titleFontSize}px Inter, system-ui, sans-serif`;
      }
      ctx.fillText(titleText, width / 2, titleY);

      // Step 6: Draw Subtitle Text (centered, zinc-300 styled italic)
      let subFontSize = isSquare ? 24 : isLandscape ? 22 : 28;
      ctx.font = `italic 500 ${subFontSize}px Inter, system-ui, sans-serif`;
      ctx.fillStyle = "#d4d4d8"; // zinc-300

      const subText = layout.subtitle || "Slogan ou description de l'affiche";
      while (ctx.measureText(subText).width > width - 160 && subFontSize > 16) {
        subFontSize -= 1;
        ctx.font = `italic 500 ${subFontSize}px Inter, system-ui, sans-serif`;
      }
      ctx.fillText(subText, width / 2, subtitleY);

      setDownloadProgress(90);

      // Step 7: Draw Button CTA
      if (layout.ctaText) {
        ctx.save();
        ctx.font = "bold 22px Inter, system-ui, sans-serif";
        const btnTextWidth = ctx.measureText(layout.ctaText.toUpperCase()).width;
        const btnW = Math.max(340, btnTextWidth + 64);
        const btnH = 80;
        const btnX = (width - btnW) / 2;
        const btnY = ctaY - btnH / 2;

        ctx.shadowColor = "rgba(0, 0, 0, 0.3)";
        ctx.shadowBlur = 15;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 6;
        drawRoundedRect(ctx, btnX, btnY, btnW, btnH, 16);
        ctx.fillStyle = layout.accentColor || "#ea580c";
        ctx.fill();

        ctx.strokeStyle = "rgba(255, 255, 255, 0.18)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();

        // Button text Centered
        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 20px Inter, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(layout.ctaText.toUpperCase(), width / 2, ctaY);
      }

      // Step 8: Brand Logo / Watermark
      ctx.fillStyle = "#71717a"; // zinc-500
      ctx.font = "600 16px Inter, monospace, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("CONÇU PAR DAK’CONTENT", width / 2, watermarkY);

      setDownloadProgress(100);

      setTimeout(() => {
        const dataUrl = canvas.toDataURL("image/png");
        const link = document.createElement("a");
        const sanitizedTitle = (layout.title || "affiche")
          .toLowerCase()
          .replace(/[^a-z0-9]/g, "_");
        link.download = `dakcontent_${sanitizedTitle}_${format}.png`;
        link.href = dataUrl;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        setDownloading(false);
        setDownloadSuccess(true);
        setTimeout(() => setDownloadSuccess(false), 3000);
      }, 400);

    } catch (err) {
      console.error("Critical render compile error:", err);
      // Fallback
      setDownloading(false);
      setDownloadSuccess(false);
    }
  };

  const aspectClasses = {
    story: "aspect-[9/16] w-full max-w-[320px]",
    square: "aspect-square w-full max-w-[380px]",
    landscape: "aspect-[16/9] w-full"
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-zinc-900/10 rounded-2xl border border-zinc-800 p-5">
      {/* Visual Canvas Panel (7 Cols) */}
      <div className="lg:col-span-7 flex flex-col items-center justify-center p-4 rounded-xl bg-zinc-950/80 border border-zinc-900 min-h-[460px]">
        
        {/* Aspect Ratio Format Switcher */}
        <div className="flex bg-zinc-900 p-1.5 rounded-lg border border-zinc-800 mb-6 gap-1 text-xs">
          <button
            onClick={() => setFormat("story")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              format === "story" ? "bg-orange-600 text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Smartphone className="h-3.5 w-3.5" /> Story 9:16
          </button>
          <button
            onClick={() => setFormat("square")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              format === "square" ? "bg-orange-600 text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Layout className="h-3.5 w-3.5" /> Carré 1:1
          </button>
          <button
            onClick={() => setFormat("landscape")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              format === "landscape" ? "bg-orange-600 text-white shadow" : "text-zinc-400 hover:text-white"
            }`}
          >
            <Tv className="h-3.5 w-3.5" /> Paysage 16:9
          </button>
        </div>

        {/* Dynamic Graphic Poster Canvas Mockup frame */}
        <div 
          className={`relative rounded-xl overflow-hidden shadow-2xl transition-all duration-300 ${aspectClasses[format]}`}
          style={{ backgroundColor: layout.bgColor }}
        >
          {/* Subtle overlay styling grid/glow for premium vibe */}
          <div className="absolute inset-0 bg-radial-gradient from-white/10 to-transparent pointer-events-none opacity-40 mix-blend-overlay" />
          
          {/* Top Header Badge */}
          {layout.badgeText && (
            <div className="absolute top-4 left-4 z-10">
              <span 
                className="inline-flex items-center gap-1 px-3 py-1 text-[11px] font-bold tracking-wider text-white uppercase rounded-full shadow-lg border border-white/20"
                style={{ backgroundColor: layout.accentColor }}
              >
                <Flame className="h-3 w-3 animate-pulse" />
                {layout.badgeText}
              </span>
            </div>
          )}

          {/* Core Visual Image Slot */}
          <div className="absolute inset-0 flex items-center justify-center p-6 h-full w-full">
            <div className="relative h-2/3 w-10/12 rounded-lg overflow-hidden border border-white/10 shadow-xl group">
              <img 
                src={displayImage} 
                alt="Product Promotion" 
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/80 to-transparent" />
            </div>
          </div>

          {/* Bottom typography and CTA container overlay */}
          <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-zinc-950 via-zinc-950/70 to-transparent text-center flex flex-col items-center justify-end">
            <h3 
              className="text-lg sm:text-xl font-bold tracking-tight text-white uppercase"
              style={{ color: "#FFF" }}
            >
              {layout.title || "Titre de l'affiche"}
            </h3>
            
            <p className="text-xs sm:text-sm text-zinc-300 font-medium tracking-wide mt-1.5 italic max-w-xs truncate">
              {layout.subtitle || "Slogan ou description de l'affiche"}
            </p>

            {/* Simulated interactive call to action button */}
            {layout.ctaText && (
              <button 
                type="button"
                className="mt-3.5 flex items-center justify-center gap-1.5 rounded-lg px-4 py-1.5 text-xs font-bold text-white uppercase tracking-wider shadow-lg border border-white/10 hover:brightness-110 active:scale-95 transition-all"
                style={{ backgroundColor: layout.accentColor || "#ea580c" }}
              >
                {layout.ctaText}
              </button>
            )}
            
            {/* Senegal emerge watermark details */}
            <span className="mt-3 block text-[9px] font-mono tracking-widest text-zinc-500">
              CONÇU PAR DAK’CONTENT
            </span>
          </div>

        </div>
      </div>

      {/* Editor & Parameter Settings Sidebar Panel (5 Cols) */}
      <div className="lg:col-span-5 flex flex-col justify-between space-y-5">
        
        {/* Controls Card */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-zinc-800">
            <Palette className="h-4.5 w-4.5 text-orange-500" />
            <h4 className="text-sm font-bold text-zinc-100">Personnaliser le Visuel</h4>
          </div>

          {/* Form fields */}
          <div className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1">
                Titre principal de l'affiche
              </label>
              <div className="relative">
                <input 
                  type="text" 
                  value={layout.title} 
                  maxLength={25}
                  onChange={(e) => handleTextChange("title", e.target.value)}
                  className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-orange-500 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1">
                Sous-titre / Message d'accroche
              </label>
              <input 
                type="text" 
                value={layout.subtitle} 
                maxLength={45}
                onChange={(e) => handleTextChange("subtitle", e.target.value)}
                className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-orange-500 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 mb-1">
                  Macaron / Offre (Badge)
                </label>
                <input 
                  type="text" 
                  value={layout.badgeText} 
                  onChange={(e) => handleTextChange("badgeText", e.target.value)}
                  className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-orange-500 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-400 mb-1">
                  Bouton d'action (CTA)
                </label>
                <input 
                  type="text" 
                  value={layout.ctaText} 
                  onChange={(e) => handleTextChange("ctaText", e.target.value)}
                  className="w-full rounded-lg bg-zinc-900 border border-zinc-800 px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-orange-500 font-medium"
                />
              </div>
            </div>

            {/* Palettes de couleurs ouest-africaines */}
            <div className="pt-2">
              <span className="block text-xs font-semibold text-zinc-400 mb-2 flex items-center gap-1.5">
                <Palette className="h-3.5 w-3.5 text-orange-500 animate-pulse" />
                Styles & Palettes d'Afrique de l'Ouest
              </span>
              <div className="grid grid-cols-2 gap-2 max-h-[175px] overflow-y-auto pr-1">
                {WEST_AFRICAN_PALETTES.map((pal) => {
                  const isActive = 
                    layout.bgColor.toLowerCase() === pal.bgColor.toLowerCase() && 
                    layout.accentColor.toLowerCase() === pal.accentColor.toLowerCase();
                  return (
                    <button
                      key={pal.name}
                      type="button"
                      onClick={() => onUpdateLayout({ 
                        ...layout, 
                        bgColor: pal.bgColor, 
                        accentColor: pal.accentColor 
                      })}
                      className={`group relative flex flex-col items-start p-2 rounded-xl border text-left transition-all cursor-pointer ${
                        isActive 
                          ? "bg-orange-600/10 border-orange-500/60 ring-1 ring-orange-500/20" 
                          : "bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900/90"
                      }`}
                    >
                      <div className="flex items-center justify-between w-full gap-2 mb-1">
                        <span className="text-[11px] font-bold text-zinc-100 group-hover:text-orange-400 font-sans transition-colors truncate">
                          {pal.name}
                        </span>
                        {/* Interactive Pill Indicators */}
                        <div className="flex gap-1 shrink-0">
                          <span 
                            className="h-3 w-3 rounded-full border border-white/15" 
                            style={{ backgroundColor: pal.bgColor }}
                            title="Couleur de fond"
                          />
                          <span 
                            className="h-3 w-3 rounded-full border border-white/15" 
                            style={{ backgroundColor: pal.accentColor }}
                            title="Couleur d'accent"
                          />
                        </div>
                      </div>
                      <span className="text-[9px] text-zinc-500 truncate w-full">
                        {pal.source}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Colors Pickers */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-zinc-400 mb-1 flex items-center gap-1">
                  <span className="inline-block h-3 w-3 rounded bg-orange-500 border border-white/10" />
                  Couleur Bouton
                </label>
                <div className="flex gap-1.5 items-center">
                  <input 
                    type="color" 
                    value={layout.accentColor} 
                    onChange={(e) => handleTextChange("accentColor", e.target.value)}
                    className="h-8 w-10 bg-transparent cursor-pointer rounded overflow-hidden"
                  />
                  <span className="text-[10px] font-mono text-zinc-400 uppercase">{layout.accentColor}</span>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-zinc-400 mb-1 flex items-center gap-1">
                  <span className="inline-block h-3 w-3 rounded bg-zinc-900 border border-white/10" />
                  Couleur Fond
                </label>
                <div className="flex gap-1.5 items-center">
                  <input 
                    type="color" 
                    value={layout.bgColor} 
                    onChange={(e) => handleTextChange("bgColor", e.target.value)}
                    className="h-8 w-10 bg-transparent cursor-pointer rounded overflow-hidden"
                  />
                  <span className="text-[10px] font-mono text-zinc-400 uppercase">{layout.bgColor}</span>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Action Button & HD Render Download Simulators */}
        <div className="pt-4 border-t border-zinc-800 space-y-3">
          {downloading ? (
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-zinc-400 font-medium">
                <span className="flex items-center gap-1.5">
                  <RefreshCw className="h-3.5 w-3.5 animate-spin text-orange-500" />
                  Compilation HD en cours...
                </span>
                <span className="font-mono text-orange-500">{downloadProgress}%</span>
              </div>
              <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-orange-600 transition-all duration-150"
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
            </div>
          ) : downloadSuccess ? (
            <div className="flex items-center gap-2 rounded-xl bg-emerald-950/40 border border-emerald-900 p-3 text-emerald-400 text-xs font-semibold">
              <CheckCircle2 className="h-5 w-5 shrink-0" />
              <span>Votre affiche HD est prête ! Téléchargé au format PNG ({format.toUpperCase()}).</span>
            </div>
          ) : (
            <button
              onClick={handleDownload}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-orange-600 hover:bg-orange-500 px-4 py-2.5 text-xs font-semibold text-white uppercase tracking-widest transition-all shadow shadow-orange-500/10 active:scale-95 cursor-pointer"
            >
              <Download className="h-4.5 w-4.5" /> Télécharger l'affiche Ultra HD
            </button>
          )}

          <p className="text-[11px] text-zinc-500 text-center">
            Optimisé pour l'affichage en statut WhatsApp, posts Instagram et stories Facebook.
          </p>
        </div>

      </div>
    </div>
  );
}
