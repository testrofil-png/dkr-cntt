import React from "react";
import { 
  LayoutDashboard, 
  Sparkles, 
  FolderHeart, 
  LayoutTemplate, 
  LineChart, 
  Wallet, 
  Settings, 
  Rocket, 
  LogOut, 
  Menu, 
  X,
  Smartphone,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { UserProfile } from "../types";

interface SidebarProps {
  currentPath: string;
  setPath: (path: string) => void;
  user: UserProfile;
  onLogout: () => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  isDarkMode: boolean;
}

export default function Sidebar({ 
  currentPath, 
  setPath, 
  user, 
  onLogout,
  isOpen,
  setIsOpen,
  isCollapsed,
  setIsCollapsed,
  isDarkMode
}: SidebarProps) {
  
  const menuItems = [
    { name: "Tableau de Bord", path: "/dashboard", icon: LayoutDashboard },
    { name: "Créer un Contenu", path: "/dashboard/create", icon: Sparkles },
    { name: "Projets Récents", path: "/dashboard/projects", icon: FolderHeart },
    { name: "Modèles d'Affiches", path: "/dashboard/templates", icon: LayoutTemplate },
    { name: "Analyses de Performance", path: "/dashboard/analytics", icon: LineChart },
    { name: "Facturation & Tarifs", path: "/dashboard/billing", icon: Wallet },
    { name: "Paramètres & API", path: "/dashboard/settings", icon: Settings },
  ];

  const creditPercentage = (user.creditsUsed / user.creditsTotal) * 100;

  const handleNav = (path: string) => {
    setPath(path);
    setIsOpen(false);
  };

  // Color classes mapping based on Theme
  const bgClass = isDarkMode ? "bg-zinc-950 border-zinc-900 text-zinc-100" : "bg-white border-slate-200 text-slate-800 shadow-sm";
  const borderClass = isDarkMode ? "border-zinc-900" : "border-slate-100";
  const hoverClass = isDarkMode ? "hover:bg-zinc-900/60 hover:text-white" : "hover:bg-slate-50 hover:text-slate-950";
  const activeClass = isDarkMode 
    ? "bg-gradient-to-r from-orange-500/10 to-transparent text-orange-505 text-white border-l-2 border-l-orange-500 font-semibold" 
    : "bg-slate-100 text-slate-950 border-l-2 border-l-orange-600 font-semibold";
  const inactiveTextClass = isDarkMode ? "text-zinc-400 group-hover:text-white" : "text-slate-500 hover:text-slate-900";

  return (
    <>
      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden transition-opacity duration-300"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Main Sidebar Wrapper */}
      <aside 
        className={`fixed inset-y-0 left-0 z-50 flex flex-col border-r transition-all duration-300 ease-in-out lg:static ${
          isCollapsed ? "w-20 px-3" : "w-72 px-5"
        } ${
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        } ${bgClass}`}
      >
        {/* Brand Header */}
        <div className={`flex items-center pb-6 pt-6 border-b ${borderClass} ${isCollapsed ? "justify-center" : "justify-between"}`}>
          <div className="flex items-center gap-3 cursor-pointer overflow-hidden" onClick={() => handleNav("/dashboard")}>
            <div className="w-8 h-8 bg-orange-600 rounded-lg flex items-center justify-center font-bold text-white tracking-tighter italic shrink-0">
              D
            </div>
            {!isCollapsed && (
              <div className="transition-all duration-300 opacity-100">
                <span className={`text-xl font-bold tracking-tight ${isDarkMode ? "text-white" : "text-slate-900"}`}>
                  Dak’Content
                </span>
                <span className="block text-[9px] font-mono tracking-widest text-zinc-500 uppercase">
                  SaaS IA Ouest-Africain
                </span>
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Collapse toggle button for desktop */}
            <button
              onClick={() => setIsCollapsed(!isCollapsed)}
              className={`hidden lg:flex items-center justify-center rounded-lg p-1.5 transition-colors ${isDarkMode ? "hover:bg-zinc-900 text-zinc-500 hover:text-white" : "hover:bg-slate-100 text-slate-400 hover:text-slate-900"}`}
              title={isCollapsed ? "Agrandir le menu" : "Réduire le menu"}
            >
              {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            </button>
            <button 
              onClick={() => setIsOpen(false)}
              className={`rounded-lg p-1.5 lg:hidden ${isDarkMode ? "hover:bg-zinc-900 text-zinc-500 hover:text-white" : "hover:bg-slate-100 text-slate-400 hover:text-slate-900"}`}
              aria-label="Fermer le menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* User Badge Profile Summary */}
        {!isCollapsed ? (
          <div className={`mt-6 flex items-center gap-3 rounded-xl border p-3 transition-opacity ${isDarkMode ? "bg-zinc-900/40 border-zinc-900/80" : "bg-slate-50 border-slate-100"}`}>
            <img 
              src={user.avatarUrl} 
              alt={user.name} 
              referrerPolicy="no-referrer"
              className="h-8 w-8 rounded-full object-cover shadow"
            />
            <div className="min-w-0 flex-1">
              <h4 className={`truncate text-sm font-semibold ${isDarkMode ? "text-zinc-200" : "text-slate-800"}`}>{user.name}</h4>
              <p className="truncate text-xs text-orange-600 font-bold">
                Plan {user.tier}
              </p>
            </div>
          </div>
        ) : (
          <div className="mt-6 flex justify-center">
            <img 
              src={user.avatarUrl} 
              alt={user.name} 
              referrerPolicy="no-referrer"
              className="h-8 w-8 rounded-full object-cover border border-orange-500/20"
              title={`${user.name} — Plan ${user.tier}`}
            />
          </div>
        )}

        {/* Navigation list */}
        <nav className="mt-8 flex-1 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item.path)}
                className={`group flex w-full items-center rounded-md text-sm transition-all py-2.5 ${
                  isCollapsed ? "justify-center px-1" : "gap-3 px-3"
                } ${
                  isActive ? activeClass : `${inactiveTextClass} ${hoverClass}`
                }`}
                title={isCollapsed ? item.name : undefined}
              >
                <Icon className={`h-4.5 w-4.5 transition-colors shrink-0 ${isActive ? "text-orange-500" : "text-zinc-500 group-hover:text-orange-500"}`} />
                {!isCollapsed && (
                  <span className="transition-opacity truncate duration-200">
                    {item.name}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Credit Usage Gauge */}
        {!isCollapsed ? (
          <div className={`mt-auto border-t pt-6 ${borderClass}`}>
            <div className={`p-3.5 w-full rounded-xl border ${isDarkMode ? "bg-zinc-900/30 border-zinc-905" : "bg-slate-50 border-slate-100"}`}>
              <div className="flex justify-between items-center mb-2">
                <span className={`text-[11px] font-bold uppercase ${isDarkMode ? "text-zinc-500" : "text-slate-400"}`}>Crédits IA</span>
                <span className="text-xs text-orange-600 font-bold">{100 - Math.round(creditPercentage)}% restants</span>
              </div>
              <div className="h-1.5 w-full bg-slate-200 dark:bg-zinc-805 bg-gray-200 rounded-full overflow-hidden dark:bg-zinc-800">
                <div 
                  className="h-full bg-orange-600 transition-all duration-500"
                  style={{ width: `${100 - Math.round(creditPercentage)}%` }}
                />
              </div>
              <p className={`text-[9px] mt-2 ${isDarkMode ? "text-zinc-500" : "text-slate-400"}`}>Renouvellement le 18 Juin 2026</p>
              
              <button
                onClick={() => handleNav("/dashboard/billing")}
                className={`mt-4.5 mt-4 flex w-full items-center justify-center gap-2 rounded-lg py-2 text-xs font-bold transition-all border ${
                  isDarkMode 
                    ? "bg-zinc-900 hover:bg-zinc-800 text-white border-zinc-800" 
                    : "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-200"
                }`}
              >
                <Rocket className="h-3.5 w-3.5 text-orange-500" />
                <span>Plus/Acheter</span>
              </button>
            </div>
          </div>
        ) : (
          <div className={`mt-auto border-t pt-6 flex justify-center ${borderClass}`}>
            <button
              onClick={() => handleNav("/dashboard/billing")}
              className={`flex h-9 w-9 items-center justify-center rounded-lg border transition-colors ${
                isDarkMode ? "bg-zinc-900 hover:bg-zinc-800 text-orange-500 border-zinc-800" : "bg-slate-100 hover:bg-slate-200 text-orange-600 border-slate-200"
              }`}
              title="Acheter des crédits"
            >
              <Rocket className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* Global Action Links */}
        <div className={`mt-4 flex flex-col gap-1 ${isCollapsed ? "items-center" : ""}`}>
          <button 
            onClick={() => handleNav("/")}
            className={`flex items-center gap-3 rounded-lg py-2 text-xs font-medium transition-all ${
              isCollapsed ? "justify-center w-9 h-9 p-0 bg-transparent text-zinc-500 hover:text-orange-500" : "px-3 text-zinc-550 text-zinc-400 hover:text-orange-550 hover:text-orange-500"
            }`}
            title="Aller au site principal"
          >
            <Smartphone className="h-4 w-4" />
            {!isCollapsed && <span>Site d'accueil web</span>}
          </button>
          
          <button 
            onClick={onLogout}
            className={`flex items-center gap-3 rounded-lg py-2 text-xs font-semibold transition-all ${
              isCollapsed 
                ? "justify-center w-9 h-9 p-0 bg-transparent text-rose-500 hover:bg-rose-50" 
                : "px-3 text-rose-500 hover:bg-rose-500/10 hover:text-rose-600"
            }`}
            title="Se déconnecter"
          >
            <LogOut className="h-4 w-4" />
            {!isCollapsed && <span>Déconnexion</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
