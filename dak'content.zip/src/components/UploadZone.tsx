import React, { useState, useRef } from "react";
import { 
  Upload, 
  Image as ImageIcon, 
  Mic, 
  MicOff, 
  Sparkles, 
  Volume2, 
  Loader2, 
  CheckCircle,
  AlertCircle
} from "lucide-react";

interface UploadZoneProps {
  onImageSelected: (base64: string) => void;
  onAudioTranscribed: (text: string) => void;
  selectedImage: string | null;
}

export default function UploadZone({ 
  onImageSelected, 
  onAudioTranscribed,
  selectedImage 
}: UploadZoneProps) {
  const [isDragActive, setIsDragActive] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [audioLoader, setAudioLoader] = useState(false);
  const [audioResult, setAudioResult] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("S'il vous plaît, uploader uniquement un fichier image.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        onImageSelected(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const triggerSelect = () => {
    fileInputRef.current?.click();
  };

  // Simulate WhatsApp/Vocal Transcription API call flawlessly
  const handleVocalSimulate = async () => {
    setIsRecording(true);
    // Simulate recording state for 2.5 seconds
    setTimeout(async () => {
      setIsRecording(false);
      setAudioLoader(true);
      try {
        const response = await fetch("/api/transcribe-vocal", {
          method: "POST",
          headers: { "Content-Type": "application/json" }
        });
        const data = await response.json();
        setAudioLoader(false);
        if (data.success && data.text) {
          setAudioResult(data.text);
          onAudioTranscribed(data.text);
        }
      } catch (e) {
        setAudioLoader(false);
        console.error("Transcription error:", e);
      }
    }, 2800);
  };

  return (
    <div className="space-y-6">
      {/* 1. Drag and Drop Zone */}
      <div 
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        onClick={triggerSelect}
        className={`group relative flex min-h-[160px] cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-6 transition-all duration-300 ${
          isDragActive 
            ? "border-orange-500 bg-orange-600/10" 
            : selectedImage 
              ? "border-emerald-500/80 bg-zinc-900/40" 
              : "border-zinc-800 bg-zinc-900/20 hover:border-orange-500/50 hover:bg-zinc-900/40"
        }`}
      >
        <input 
          ref={fileInputRef}
          type="file" 
          accept="image/*" 
          onChange={handleChange}
          className="hidden" 
        />

        {selectedImage ? (
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <img 
                src={selectedImage} 
                alt="Selected Product" 
                referrerPolicy="no-referrer"
                className="h-28 w-28 rounded-xl object-cover border border-emerald-500/30 shadow-md"
              />
              <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-[10px] font-bold text-white shadow">
                ✓
              </span>
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-emerald-400">Photo produit chargée avec succès !</p>
              <p className="text-xs text-zinc-400 mt-1">Cliquez ou glissez une autre photo pour la remplacer</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-800/80 text-zinc-400 group-hover:bg-orange-500/10 group-hover:text-orange-500 transition-colors">
              <Upload className="h-6 w-6" />
            </div>
            <p className="text-sm font-bold text-zinc-200">
              Déposez votre photo produit ici
            </p>
            <p className="mt-1 text-xs text-zinc-400">
              Glissez-déposez ou <span className="text-orange-500 underline font-medium">parcourez votre galerie</span>
            </p>
            <p className="mt-2 text-[10px] text-zinc-500">
              Formats supportés : PNG, JPG, WEBP (Max 5Mo)
            </p>
          </div>
        )}
      </div>

      {/* 2. Whatsapp Voice note transcription simulation */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/30 p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400">
            <Volume2 className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-zinc-100">Upload Vocal WhatsApp ou Dictée</h4>
            <p className="text-xs text-zinc-400">Pas le temps d'écrire ? Décrivez votre produit à haute voix !</p>
          </div>
        </div>

        {/* Action button trigger simulator */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          {isRecording ? (
            <button
              type="button"
              className="flex w-full sm:w-auto items-center justify-center gap-3 rounded-xl bg-rose-600 px-5 py-3 text-sm font-semibold text-white animate-pulse shadow-lg shadow-rose-600/20"
            >
              <MicOff className="h-4 w-4" />
              <span>Enregistrement en cours... Écoutez 🗣️</span>
            </button>
          ) : audioLoader ? (
            <button
              type="button"
              disabled
              className="flex w-full sm:w-auto items-center justify-center gap-3 rounded-xl bg-zinc-800 px-5 py-3 text-sm font-semibold text-zinc-400 cursor-not-allowed"
            >
              <Loader2 className="h-4 w-4 animate-spin text-orange-500" />
              <span>Déchiffrement de votre voix en wolof/français...</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleVocalSimulate}
              className="flex w-full sm:w-auto items-center justify-center gap-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-5 py-3 text-sm font-bold text-white transition-all shadow-md shadow-emerald-600/10 hover:shadow-emerald-500/25"
            >
              <Mic className="h-4 w-4" />
              <span>Simuler Note Vocale WhatsApp</span>
            </button>
          )}

          <span className="text-[11px] text-zinc-400 italic text-center sm:text-left">
            Idéal pour les commerçants pressés (Dakar, Abidjan, Bamako) !
          </span>
        </div>

        {/* Feedback results of transcription */}
        {audioResult && (
          <div className="mt-4 rounded-xl bg-zinc-950 border border-zinc-850 p-3.5 text-xs text-zinc-300 relative">
            <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-400 uppercase mb-1.5 font-mono">
              <CheckCircle className="h-3 w-3" /> Transcrit par Whispering AI :
            </div>
            <p className="leading-relaxed bg-zinc-900/60 p-2.5 rounded-lg border border-zinc-900">
              "{audioResult}"
            </p>
            <p className="mt-2 text-[10px] text-orange-400 flex items-center gap-1">
              <Sparkles className="h-3 w-3 " />
              Ce texte a été injecté directement dans le formulaire de description ci-dessous.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
