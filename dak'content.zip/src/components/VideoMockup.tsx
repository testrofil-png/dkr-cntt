import React, { useState, useEffect, useRef } from "react";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Clapperboard, 
  Compass, 
  Music, 
  VolumeX, 
  Volume2, 
  Smartphone, 
  Sparkles,
  ArrowRight,
  Flame,
  CheckCircle2,
  Tv
} from "lucide-react";
import { TiktokScript, VideoScene } from "../types";

interface VideoMockupProps {
  script: TiktokScript;
  productImage?: string;
  categoryName?: string;
}

export default function VideoMockup({ 
  script, 
  productImage,
  categoryName 
}: VideoMockupProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeSceneIndex, setActiveSceneIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [audioMood, setAudioMood] = useState<"afrobeat" | "coupe" | "kora" | "jazz" | "none">("afrobeat");
  const [videoFormat, setVideoFormat] = useState<"portrait" | "square">("portrait");

  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const scenes = script.scenes || [
    { sceneNumber: 1, description: "Zoom serré sur l'article avec musique tendance.", textOverlay: "Qualité Premium", voiceOver: "Entrez dans une nouvelle dimension de qualité." },
    { sceneNumber: 2, description: "Geste de démonstration avec le sourire.", textOverlay: "Création d'Exception", voiceOver: "Votre idéal au meilleur prix d'Afrique de l'Ouest." },
    { sceneNumber: 3, description: "Wave QR code et numéro de téléphone mobile.", textOverlay: "Commande Express", voiceOver: "Faites-vous livrer chez vous aujourd'hui !" }
  ];

  const displayImage = productImage || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600";

  useEffect(() => {
    if (isPlaying) {
      progressIntervalRef.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            // Loop or stop
            setActiveSceneIndex(0);
            return 0;
          }
          const nextProgress = prev + 1;
          
          // Determine active scene based on progress percentage
          const sceneStep = 100 / scenes.length;
          const currentScene = Math.floor(nextProgress / sceneStep);
          if (currentScene < scenes.length && currentScene !== activeSceneIndex) {
            setActiveSceneIndex(currentScene);
          }
          
          return nextProgress;
        });
      }, 100); // 10s total video length simulation
    } else {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    }

    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, [isPlaying, activeSceneIndex, scenes.length]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setIsPlaying(false);
    setProgress(0);
    setActiveSceneIndex(0);
  };

  const activeScene: VideoScene = scenes[activeSceneIndex] || scenes[0];

  const moodTracks = {
    afrobeat: "Dakar Energetic Afrobeat 🥁",
    coupe: "Abidjan Coupé-Décalé Bass ⚡",
    kora: "Traditional Senegal Kora Melody 🪕",
    jazz: "Lagos Chill Lounge Jazz 🎷",
    none: "Silence (Pas de musique) 🔇"
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-zinc-900/10 rounded-2xl border border-zinc-800 p-5">
      {/* 1. Phone Frame Preview (5 Cols) */}
      <div className="md:col-span-12 lg:col-span-5 flex flex-col items-center">
        
        {/* Format switchers */}
        <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-900 mb-4 gap-1 text-[11px] self-center">
          <button
            onClick={() => setVideoFormat("portrait")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              videoFormat === "portrait" ? "bg-orange-600 text-white" : "text-zinc-400"
            }`}
          >
            <Smartphone className="h-3.5 w-3.5" /> Portrait 9:16 (TikTok / Reels)
          </button>
          <button
            onClick={() => setVideoFormat("square")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
              videoFormat === "square" ? "bg-orange-600 text-white" : "text-zinc-400"
            }`}
          >
            <Tv className="h-3.5 w-3.5" /> Carré 1:1
          </button>
        </div>

        {/* Video simulation screen container */}
        <div 
          className={`relative rounded-3xl border-4 border-zinc-805 border-zinc-800 bg-black overflow-hidden shadow-2xl transition-all duration-300 ${
            videoFormat === "portrait" ? "aspect-[9/16] w-[260px] " : "aspect-square w-[310px] "
          }`}
        >
          {/* Main Visual background - applying CSS Ken Burns animations while isPlaying is active! */}
          <div className="absolute inset-0 h-full w-full">
            <img 
              src={displayImage} 
              alt="Video Promo Background" 
              referrerPolicy="no-referrer"
              className={`h-full w-full object-cover origin-center opacity-85 transition-all duration-1000 ${
                isPlaying ? "scale-110 filter contrast-110" : "scale-100"
              }`}
            />
            {/* Dynamic visual overlay corresponding to each scene and state */}
            <div className={`absolute inset-0 transition-all duration-500 ${
              activeSceneIndex === 0 
                ? "bg-orange-500/10" 
                : activeSceneIndex === 1 
                  ? "bg-rose-500/10" 
                  : "bg-blue-500/10"
            }`} />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/85" />
          </div>

          {/* AI Voice Indicator Wave lines (Bottom right to look nice and alive) */}
          {isPlaying && (
            <div className="absolute top-4 right-4 z-20 flex gap-0.5 items-end justify-center h-5">
              <span className="w-0.75 bg-orange-500 rounded animate-[bounce_1s_infinite_100ms]" style={{ height: "40%" }} />
              <span className="w-0.75 bg-orange-500 rounded animate-[bounce_1s_infinite_300ms]" style={{ height: "100%" }} />
              <span className="w-0.75 bg-orange-500 rounded animate-[bounce_1s_infinite_500ms]" style={{ height: "60%" }} />
              <span className="w-0.75 bg-orange-500 rounded animate-[bounce_1s_infinite_200ms]" style={{ height: "80%" }} />
            </div>
          )}

          {/* Social Overlays watermark mockup (TikTok design feeling) */}
          <div className="absolute left-3 bottom-24 right-3 text-left">
            <div className="flex items-center gap-1 text-[10px] font-bold text-white mb-1 bg-black/40 px-2 py-0.5 rounded-full w-fit max-w-full">
              <Sparkles className="h-2.5 w-2.5 text-orange-500" />
              <span>@DakContent_VoiceOver_AI</span>
            </div>
            <p className="text-xs font-bold text-white truncate drop-shadow-md">
              📣 {script.hook || "Le produit du siècle est là !"}
            </p>
          </div>

          {/* KEY DYNAMIC KINETIC SUBTITLE OVERLAY: REPRESENTING LOUDSPEAKER VOICE OVER */}
          <div className="absolute inset-x-2 bottom-6 text-center z-10">
            <div className="inline-block bg-zinc-950/90 rounded-xl border border-zinc-800/80 px-3 py-2">
              <span className="block text-[10px] font-bold tracking-widest text-zinc-400 uppercase mb-0.5 font-mono">
                🗣️ VOIX IA EN COURS :
              </span>
              <p className="text-xs text-orange-400 font-bold tracking-tight">
                "{activeScene.voiceOver}"
              </p>
            </div>
          </div>

          {/* UPPER DYNAMIC TEXT OVERLAY REPRESENTING THE SCREEN TEXT */}
          <div className="absolute inset-x-4 top-1/4 text-center z-10 pointer-events-none">
            <span className="inline-block bg-orange-600 rounded-lg px-4 py-2 text-sm font-bold text-white uppercase tracking-wider shadow-lg border border-white/20">
              🚀 {activeScene.textOverlay}
            </span>
            <span className="block mt-2 text-[10px] text-white/70 font-mono drop-shadow-md">
              (Scène {activeScene.sceneNumber} / {scenes.length})
            </span>
          </div>

          {/* Progress gauge bar */}
          <div className="absolute bottom-0 inset-x-0 h-1 bg-zinc-900">
            <div 
              className="h-full bg-orange-600 transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>

        </div>

        {/* Video player controls */}
        <div className="flex items-center gap-3 mt-4">
          <button
            onClick={togglePlay}
            className={`flex h-11 w-11 items-center justify-center rounded-full text-white shadow shadow-orange-500/20 ${
              isPlaying ? "bg-zinc-200 text-zinc-900 hover:bg-white" : "bg-orange-600 hover:bg-orange-500"
            }`}
          >
            {isPlaying ? <Pause className="h-5 w-5 text-zinc-950" /> : <Play className="h-5 w-5 fill-white" />}
          </button>
          
          <button
            onClick={handleReset}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
            title="Recommencer"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

      </div>

      {/* 2. Audio Control & Scenes Breakdown Panel (7 Cols) */}
      <div className="md:col-span-12 lg:col-span-7 space-y-5 flex flex-col justify-between">
        
        {/* Track selection section */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 pb-2.5 border-b border-zinc-800">
            <Music className="h-4.5 w-4.5 text-orange-500 animate-pulse" />
            <h4 className="text-sm font-bold text-zinc-100">Fond Sonore et Ambiance</h4>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {Object.entries(moodTracks).map(([key, name]) => (
              <button
                key={key}
                onClick={() => setAudioMood(key as any)}
                className={`text-left p-2.5 rounded-lg border transition-all ${
                  audioMood === key 
                    ? "bg-orange-600/10 border-orange-500/50 text-orange-500 font-semibold" 
                    : "bg-zinc-900/40 border-zinc-800 hover:bg-zinc-900/80 text-zinc-300"
                }`}
              >
                {name}
              </button>
            ))}
          </div>
        </div>

        {/* Scenes sequence timeline step by step */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 pb-2.5 border-b border-zinc-800">
            <Clapperboard className="h-4.5 w-4.5 text-orange-500" />
            <h4 className="text-sm font-bold text-zinc-100">Séquences de Scènes Vidéos</h4>
          </div>

          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
            {scenes.map((scene, idx) => {
              const isActive = activeSceneIndex === idx;
              return (
                <div 
                  key={idx}
                  onClick={() => {
                    setActiveSceneIndex(idx);
                    setProgress(idx * (100 / scenes.length) + 5);
                  }}
                  className={`cursor-pointer rounded-xl border p-3 transition-all ${
                    isActive 
                      ? "bg-zinc-900 border-orange-500/40 text-white pl-4" 
                      : "bg-zinc-950/40 border-zinc-900 text-zinc-400 hover:bg-zinc-900/30"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1">
                      <span className={`h-1.5 w-1.5 rounded-full ${isActive ? "bg-orange-500 animate-pulse" : "bg-zinc-700"}`} />
                      Scène {scene.sceneNumber} : {scene.textOverlay}
                    </span>
                    {isActive && (
                      <span className="text-[9px] font-bold text-orange-500 font-mono flex items-center gap-1 bg-orange-600/10 px-1.5 py-0.5 rounded">
                        Active live
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-zinc-300 italic mb-1">
                    🎥 Caméra : {scene.description}
                  </p>
                  <p className="text-xs text-zinc-200">
                    🎙️ Voice-over : <span className="font-semibold text-orange-400">"{scene.voiceOver}"</span>
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action output info */}
        <div className="pt-3.5 border-t border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-3 text-[11px] text-zinc-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
            <span>Voix off générée en français & mélodie {moodTracks[audioMood]} intégrée !</span>
          </div>
          <span className="text-orange-500 font-bold font-mono">
            Durée totale : ~10 secondes (Idéal Shorts/Reels)
          </span>
        </div>

      </div>
    </div>
  );
}
