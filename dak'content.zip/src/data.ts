import { Template, Invoice } from "./types";

export const STAGE_TEMPLATES: Template[] = [
  {
    id: "tpl-1",
    title: "Wax d'Afrique Premium",
    category: "Mode",
    description: "Parfait pour valoriser les robes créateur, kaftans dorés et tissus d'exception.",
    imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600",
    badge: "Populaire",
    bgColor: "#1E1B4B",
    textColor: "#FDFFFE",
    accentColor: "#D97706"
  },
  {
    id: "tpl-2",
    title: "Thiébou Royal Gourmand",
    category: "Restauration",
    description: "Mettez en valeur vos plats phares (thiéboudienne, yassa, mafé poulet).",
    imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=600",
    badge: "Nouveau",
    bgColor: "#7C2D12",
    textColor: "#FFFBEB",
    accentColor: "#EF4444"
  },
  {
    id: "tpl-3",
    title: "Villa Prestige Almadies",
    category: "Immobilier",
    description: "Design épuré pour agences immobilières et locations saisonnières de prestige.",
    imageUrl: "https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&q=80&w=600",
    badge: "Premium",
    bgColor: "#0F172A",
    textColor: "#F8FAFC",
    accentColor: "#3B82F6"
  },
  {
    id: "tpl-4",
    title: "Nappy Hair Queen",
    category: "Beauté",
    description: "Valorisez vos tresses protectrices, soins capillaires bios et salons locaux.",
    imageUrl: "https://images.unsplash.com/photo-1605497746444-ac9da58d440f?auto=format&fit=crop&q=80&w=600",
    badge: "Best Seller",
    bgColor: "#3F2F11",
    textColor: "#FFFDF5",
    accentColor: "#F59E0B"
  },
  {
    id: "tpl-5",
    title: "Eco Tech Abidjan",
    category: "Électronique",
    description: "Optimisé pour des lancements de smartphones, ordinateurs et accessoires reconditionnés.",
    imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&q=80&w=600",
    badge: "-15% Wave",
    bgColor: "#091E13",
    textColor: "#E6F4EA",
    accentColor: "#10B981"
  },
  {
    id: "tpl-6",
    title: "Jus Local Bissap Impérial",
    category: "Alimentation",
    description: "Design rafraîchissant pour boisson locale naturelle de gingembre ou bouye.",
    imageUrl: "https://images.unsplash.com/photo-1536935338788-846bb9981813?auto=format&fit=crop&q=80&w=600",
    badge: "Bio",
    bgColor: "#4C0519",
    textColor: "#FFE4E6",
    accentColor: "#F43F5E"
  },
  {
    id: "tpl-7",
    title: "Dakar Prestige Cars",
    category: "Automobile",
    description: "Pour la location de berlines et SUV haut de gamme de cérémonies.",
    imageUrl: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&q=80&w=600",
    badge: "VIP",
    bgColor: "#1C1917",
    textColor: "#F5F5F4",
    accentColor: "#A8A29E"
  }
];

export const PRI_PLANS = [
  {
    id: "plan-starter",
    title: "Starter",
    price: "9 900",
    currency: "FCFA / mois",
    equivalentUsd: "≈ 15 €",
    credits: "50 crédits IA",
    features: [
      "Génération de posts Facebook & Instagram",
      "Génération de slogans & tags illimités",
      "Affiches marketing intelligentes (Standard)",
      "Formats Story & Carré",
      "Support standard par WhatsApp/Courriel"
    ],
    popular: false,
    color: "from-blue-600 to-indigo-600"
  },
  {
    id: "plan-pro",
    title: "Pro (Sénégal & Côte d'Ivoire)",
    price: "24 500",
    currency: "FCFA / mois",
    equivalentUsd: "≈ 37 €",
    credits: "200 crédits IA",
    features: [
      "Tout ce qui est dans Starter",
      "Générateur de mini-vidéos TikTok & Reels",
      "Affiches Édition Canvas Premium",
      "Transcripteur vocal WhatsApp intelligent",
      "Tous formats d'exportation (PNG, MP4, PDF)",
      "Support d'aide VIP sénégalais & ivoirien"
    ],
    popular: true,
    color: "from-amber-600 to-rose-600"
  },
  {
    id: "plan-business",
    title: "Business Global",
    price: "49 000",
    currency: "FCFA / mois",
    equivalentUsd: "≈ 75 €",
    credits: "Crédits illimités *",
    features: [
      "Tout ce qui est dans Pro",
      "Générateur de marque complet multi-produit",
      "IA personnalisée avec le ton de votre boutique",
      "Utilisateurs multiples (jusqu'à 5 membres)",
      "Appel d'onboarding mensuel avec un expert marketing",
      "Accès API exclusive Dak’Content"
    ],
    popular: false,
    color: "from-purple-600 to-pink-600"
  }
];

export const INVOICE_DATA: Invoice[] = [
  {
    id: "FAC-2026-004",
    amount: 24500,
    date: "2026-05-18",
    status: "Payé",
    method: "Wave"
  },
  {
    id: "FAC-2026-003",
    amount: 24500,
    date: "2026-04-18",
    status: "Payé",
    method: "Orange Money"
  },
  {
    id: "FAC-2026-002",
    amount: 9900,
    date: "2026-03-18",
    status: "Payé",
    method: "Wave"
  },
  {
    id: "FAC-2026-001",
    amount: 9900,
    date: "2026-02-18",
    status: "Payé",
    method: "Wave"
  }
];

export const FREQUENT_QUESTIONS = [
  {
    question: "Qu'est-ce que Dak'Content et comment m'aide-t-il ?",
    answer: "Dak’Content est un SaaS révolutionnaire conçu pour l'Afrique francophone. Il rédige vos argumentaires de vente, conçoit vos affiches publicitaires et monte des scripts vidéo TikTok engageants en moins de 30 secondes à partir d'une simple idée ou photo produit."
  },
  {
    question: "Comment puis-je payer mon abonnement ?",
    answer: "Nous acceptons les méthodes de paiements locales de référence : Wave Sénégal et Orange Money (Sénégal/Côte d'Ivoire)."
  },
  {
    question: "Comment fonctionne la transcription audio WhatsApp ?",
    answer: "Plutôt que d'écrire, vous pouvez uploader une note vocale enregistrée sur WhatsApp depuis votre smartphone. Dak’Content utilise notre API Whisper et Gemini pour transcrire l'audio et générer une superbe campagne marketing complète."
  },
  {
    question: "Puis-je modifier l'affiche publicitaire générée ?",
    answer: "Oui ! Notre mini-éditeur convivial vous permet de repositionner les éléments, modifier le texte marketing, adapter le thème de couleur et télécharger l'export haute définition prêt à envoyer sur vos pages Facebook ou statuts WhatsApp."
  },
  {
    question: "Les crédits se rechargent-ils automatiquement ?",
    answer: "Oui, vos crédits se réinitialisent chaque mois à la date anniversaire de votre inscription en fonction du plan d'abonnement sélectionné."
  }
];
