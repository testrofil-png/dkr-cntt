export interface PosterLayout {
  title: string;
  subtitle: string;
  accentColor: string;
  bgColor: string;
  badgeText: string;
  ctaText: string;
}

export interface VideoScene {
  sceneNumber: number;
  description: string;
  textOverlay: string;
  voiceOver: string;
}

export interface TiktokScript {
  hook: string;
  scenes: VideoScene[];
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  slogan: string;
  facebookText: string;
  instagramCaption: string;
  hashtags: string[];
  campaignType: string;
  createdAt: string;
  imageUrl?: string;
  posterLayout: PosterLayout;
  tiktokScript: TiktokScript;
}

export interface Template {
  id: string;
  title: string;
  category: "Mode" | "Restauration" | "Beauté" | "Électronique" | "Immobilier" | "Alimentation" | "Automobile" | "Autre";
  description: string;
  imageUrl: string;
  badge: string;
  bgColor: string;
  textColor: string;
  accentColor: string;
}

export interface UserProfile {
  name: string;
  email: string;
  companyName: string;
  preferredCategory: string;
  country: string;
  avatarUrl: string;
  creditsUsed: number;
  creditsTotal: number;
  tier: "Starter" | "Pro" | "Business";
  isLoggedIn: boolean;
}

export interface Invoice {
  id: string;
  amount: number;
  date: string;
  status: "Payé" | "En attente";
  method: "Wave" | "Orange Money" | "Cash";
}
